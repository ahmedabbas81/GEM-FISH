function get_local_structures_Rao(chr_number,ntads,vol_chr_orig,size_chr_orig,g_s_exp,parent_dir,g_length_original,resolution,slope)
mkdir(parent_dir);
lambdaE = 5E11;
lambdaR = 1E-7;
for i = 1 : ntads
    fprintf('Calculating intra-TAD 3D model of TAD %d \n',i);
    dir_name = sprintf('%s/tad%d',parent_dir,i);
    mkdir(dir_name);
    hic_file = sprintf('./Rao_files_%s_5kb/hic_matrix_tad_%d_Rao_5kb.txt',chr_number,i-1);
    loci_file = sprintf('./Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_number,i-1);
    l = load(loci_file);
    g_length_current = l(size(l,1)) - l(1) + resolution;
    GEM_FISH_LOCALS(hic_file, loci_file, 1E5, lambdaE, 0,-1,lambdaR,g_s_exp,dir_name,vol_chr_orig,size_chr_orig,g_length_original,g_length_current,slope);
end

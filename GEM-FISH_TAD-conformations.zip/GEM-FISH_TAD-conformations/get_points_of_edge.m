function points_of_an_edge = get_points_of_edge(P1, P2, resolution)
l = P2(1) - P1(1);
m = P2(2) - P1(2);
n = P2(3) - P1(3);
if(abs(l)>abs(m) && abs(l)>abs(n))
    ind1 = 1;   
    ind2 = 2;
    ind3 = 3;
    s_ind1 = l;
    s_ind2 = m;
    s_ind3 = n;
elseif(abs(m)>abs(l) && abs(m)>abs(n))
    ind1 = 2;
    ind2 = 1;
    ind3 = 3;
    s_ind1 = m;
    s_ind2 = l;
    s_ind3 = n;
else
    ind1 = 3;
    ind2 = 1;
    ind3 = 2;
    s_ind1 = n;
    s_ind2 = l;
    s_ind3 = m;
end
if(P1(ind1) > P2(ind1))
    x1 = P2(ind1);%+resolution;
    x2 = P1(ind1);%-resolution;
    y1 = P2(ind2);
    z1 = P2(ind3);
    points_of_an_edge(1,:) = P2(:);
else
    x1 = P1(ind1);%+resolution;
    x2 = P2(ind1);%-resolution;
    y1 = P1(ind2);
    z1 = P1(ind3);
    points_of_an_edge(1,:) = P1(:);
end
k = 2;
for i = x1:resolution:x2
    delta = (i - (x1-resolution))/s_ind1;
    P(ind1) = i;
    P(ind2) = s_ind2*delta+y1;
    P(ind3) = s_ind3*delta+z1;
    points_of_an_edge(k,:) = P(:);
    k = k + 1;
end
function [structure_min,proportions_min,C_min,C1_min,C2_min,C3_min]=Optimizer(X,loci,max_iter,M,lambdaE,lambdaF,fish_distances,a_coef,g_s_exp)

% This function is for the two-stage optimization process that considers both Hi-C data, FISH data, and conformation energy.

n=size(loci,1);
for trial=1:3
    disp (['Trial ' num2str(trial) ':']);
    
    %disp ('Average-structure optimization');
    % Initialization
    structure=5000*rand(n,3,1);
    structure = bsxfun(@minus, structure, mean(structure, 1));
    % Average-structure optimization
    [structure,proportions,C,C1,C2,C3] = BasicOptCell( structure, X,loci,max_iter,1,lambdaE,lambdaF,fish_distances,a_coef,g_s_exp);
    
    %disp ('Multi-conformation optimization');
    % Initialization from the precomputed average structure
    structure=structure(:,:,ones(1,M))+randn(n,3,M);
    structure = bsxfun(@minus, structure, mean(structure, 1));  
    % Multi-conformation optimization
    [structure,proportions,C,C1,C2,C3] = BasicOptCell( structure, X,loci,max_iter,M,lambdaE,lambdaF,fish_distances,a_coef,g_s_exp);
    
    % Find the smallest cost and its structure among three trails
    if trial==1
        C_min=C;
        structure_min=structure;
        proportions_min=proportions;
        C1_min=C1;
        C2_min=C2;
        C3_min=C3;
    end
    if trial >1
        if C_min>C
            C_min=C;
            structure_min=structure;
            proportions_min=proportions;
            C1_min=C1;
            C2_min=C2;
            C3_min=C3;
        end
    end
end

end
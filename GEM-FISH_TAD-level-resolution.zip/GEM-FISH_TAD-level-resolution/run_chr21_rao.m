dir_of_results='chr_21_TAD_level_resolution';
chr_num_string='21';
% if the spatial distance vs. genomic distance relation is: s = a * g^b, where a and b are determined using the experimental FISH data for each individual chromosome 
a = 0.038;
b = 0.21;
% lambdaE and lambdaF are selected as described in Section 4.3 in the paper
lambdaE=12;
lambdaF=-8;
run_gem_general_Rao(dir_of_results,chr_num_string,a,b,lambdaE,lambdaF);

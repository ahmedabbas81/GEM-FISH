//remember tad positions in hg19

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>
//#include <direct.h>
#include <math.h>
//#define raw_lines 526255
//#define KR_lines 1928
using namespace std;
int main()
{
  ifstream fconfig("config.txt");
  //read the config file entries
  char field_name[100], field[100];
  char raw_HiC_file_path[100];
  char normalization_file_path[100];
  char tads_positions_file_path[100];
  char output_HiC_matrix_tad_level_path[100];
  char output_big_contact_matrix_path[100];
  char output_loci_file_tad_level_path[100];
  char output_files_path[100];
  int resolution;
  int i = 0;
  int normalize_flag = 1;
  while(!fconfig.eof())
  {
    fconfig>>field_name>>field;
    i = i + 1;
    if(strcmp(field_name,"raw_Hi-C_file:") == 0)
      strcpy(raw_HiC_file_path,field);
    else if(strcmp(field_name,"Normalization_file:") == 0)
      strcpy(normalization_file_path,field);
    else if(strcmp(field_name,"tads_positions_file:") == 0)
      strcpy(tads_positions_file_path,field);
    else if(strcmp(field_name,"Output_directory:") == 0)
      strcpy(output_files_path,field);
    else if(strcmp(field_name,"Output_Hi-C_matrix_tads_level:") == 0)
      strcpy(output_HiC_matrix_tad_level_path,field);
    else if(strcmp(field_name,"Output_loci_file_tads_level:") == 0)
      strcpy(output_loci_file_tad_level_path,field);
    else if(strcmp(field_name,"Output_Hi-C_matrix_loci_level:") == 0)
      strcpy(output_big_contact_matrix_path,field);
    else if(strcmp(field_name,"resolution:") == 0)
      resolution = atoi(field);
    else if(strcmp(field_name,"normalized_flag:") == 0)
      normalize_flag = atoi(field);
    else
    {
      ////cout<<"Unknown Entry in Config file at line: "<<i<<", will terminate program"<<endl;
      return 0;
    }
        
  }
  ////cout<<"\nfinished reading config file";
  //mkdir(output_files_path);
  ifstream fraw(raw_HiC_file_path);
  ////cout<<raw_HiC_file_path<<endl;
  
  if(fraw.bad() == 1)
  {
    ////cout<<"The path of raw Hi-C file is wrong, will terminate the program\n";
    return 0;
  }
  ifstream fnorm(normalization_file_path);
  if(fnorm.bad() == 1)
  {
    ////cout<<"The path of normalization file is wrong, will terminate the program\n";
    return 0;
  }
  ifstream ftads(tads_positions_file_path);
  if(ftads.bad() == 1)
  {
    ////cout<<"The path of tads file is wrong, will terminate the program\n";
    return 0;
  }
	ofstream f_out_tads(output_HiC_matrix_tad_level_path);
	////////////////////////Start Processing///////////////////////////////
	int tad_bp1, tad_bp2;           //temp variables to read positions of tads
	int n_tads = 0;
	//get the number of tads and put in n_tads
    char el1[20],el2[20],el3[20];
	while(!ftads.eof())
	{
	  ftads>>el1>>el2;
      n_tads++;
      //cout<<n_tads<<endl;
	}
	ftads.close();
	cout<<"\nfinished reading tads file\n";
	//define arrays to store tad positions and tad positions in terms of block number
	int **tads, **tad_indexes;
	tads = new int*[n_tads];
	tad_indexes = new int*[n_tads];
	for(i = 0; i < n_tads; i++)
	{
	  tads[i] = new int[3];
	  tad_indexes[i] = new int[2];
	}
	ftads.open(tads_positions_file_path);
	int ind = 0;
	while(!ftads.eof())
	{
        
      if(ind >= n_tads)
          break;
	  ftads>>tads[ind][0]>>tads[ind][1];
	  tads[ind][2] = ceil((tads[ind][1] - tads[ind][0])/resolution);      //third column in tads array is number of blocks in every tad
	  tad_indexes[ind][0] = floor(tads[ind][0]/resolution);               //tad_indexes stores positions of tads in terms of block numbers
	  if(tads[ind][1]%resolution==0)
	    tad_indexes[ind][1] = floor(tads[ind][1]/resolution) - 1;
	  else
	    tad_indexes[ind][1] = floor((tads[ind][1]-(tads[ind][1]%resolution))/resolution)-1;
      
      	  //cout<<tads[ind][0]<<","<<tads[ind][1]<<","<<tads[ind][2]<<endl;
	  ind++;
      
	}
	
	//define hic_matrix to store HiC frequencies at tad resolution
	double **hic_matrix;
	hic_matrix = new double*[n_tads];
	for(i = 0; i < n_tads; i++)
	{
	  hic_matrix[i] = new double[n_tads];
	}
	
	//double hic_matrix_Normalized_Whole[34][34];
	//double hic_matrix_Normalized_Without_Zeros[34][34];
	int j;
	int row_final, col_final;
	//initialize hic_matrix with zeros
	for(i = 0; i < n_tads; i++)
	{
		for(j = 0; j < n_tads; j++)
		{
			hic_matrix[i][j] = 0;
		}
	}
	int raw_lines = 0;
	
	//get number of lines in raw file and put it in raw_lines
    int bp1, bp2;
    double cf;
	while(!fraw.eof())
	{
	  fraw>>bp1>>bp2>>cf;
	  //cout<<raw_lines<<endl;
      raw_lines++;
	}
    if(fraw.is_open())
    {
        //cout<<"\ntrying to close";
        fraw.close();
        cout<<"\nclosed";
        
    }
    else
        cout<<"already closed";
	//cout<<"\nfinished reading raw file";
	double **raw_data;
	raw_data = new double*[raw_lines];
	for(i = 0; i < raw_lines; i++)
    {
        //////cout<<i<<" from "<<raw_lines<<endl;
		raw_data[i] = new double[3];
    }
    
    ////cout<<"\ncreated raw_data";
	//get number of lines in normalization file
	int KR_lines = 0;
    string e;
    char tmp[30];
	while(getline(fnorm,e))//(!fnorm.eof())
	{
	  
      KR_lines++;
      //////cout<<KR_lines<<endl;
	}
    //cout<<KR_lines<<endl;
	fnorm.close();
    //--KR_lines;
	////cout<<"\nfinished reading norm file";
	double *KR_norm = new double[KR_lines];
	//int bp1, bp2;
	double contacts;
	i = 0;
	double entry;
	int rows = 0, cols = 0;
	//reopen raw data file
	fraw.open(raw_HiC_file_path);
	ind = 0;
	while(!fraw.eof())
	{
        if(rows >= raw_lines)
            break;
		fraw>>raw_data[rows][0]>>raw_data[rows][1]>>raw_data[rows][2];
	    //////cout<<"\n"<<rows;
		rows++;
	}
	fraw.close();
	cout<<"\nfinished reading raw file";
	fnorm.open(normalization_file_path);
	rows = 0;
	char element[30];
    //fnorm.open(normalization_file_path);
	while(getline(fnorm,e))
	{
        if(rows >= KR_lines)
        {
            //cout<<"\ngetting out  "<<rows<<endl;
            break;
        }
		//fnorm>>element;
        //////cout<<"\nNormalization file "<<rows<<": "<<strtod(element,NULL)<<endl;
      strcpy(element,e.c_str());
	  if(strcmp(element,"NaN") != 0)
      {
          KR_norm[rows] = atof(element);
      }
	  else
	      KR_norm[rows] = -10;
        
      //cout<<"\n Final   "<<rows<<",  "<<element<<",\t"<<KR_norm[rows]<<endl;
	  rows++;
	}
	fnorm.close();
	cout<<"\nfinished reading norm file";
	int nan_cases = 0;
	int ind1, ind2;
	int max_ind = 0;
	double n1, n2;
	//after the next loop raw_data will be normalized
	for(i = 0; i<raw_lines; i++)
	{
		//cout<<i<<"/"<<raw_lines<<endl;
		ind1 = int(raw_data[i][0]/resolution); //removed '+1' from the original formula because array starts from element 0
		n1 = KR_norm[ind1];
		//////cout<<n1<<endl;
		ind2 = int(raw_data[i][1]/resolution);
		n2 = KR_norm[ind2];
		//////cout<<n2<<endl;
		if(normalize_flag == 1)
		{
  		if(n1 != -10 && n2 != -10)
  			raw_data[i][2]/= (n1*n2);
  		else
  			raw_data[i][2] = 0;
		}
		
		if(ind1 > max_ind)
			max_ind = ind1;
		if(ind2 > max_ind)
		  max_ind = ind2;
	}
    cout<<"\nfinished normalizing data";
	max_ind++; //to create array with correct number of elements
	//cout<<max_ind<<endl;
	//Build the big contact matrix
	double **Contact_Matrix;//[1000][1000];
    //max_ind = tad_indexes[n_tads-1][1]+1;
	Contact_Matrix = new double* [max_ind];
	for(i = 0; i < max_ind; i++)
		Contact_Matrix[i] = new double[max_ind];
	//cout<<raw_lines<<endl;
    //Contact_Matrix[17][12426] = 1000;
    ////cout<<Contact_Matrix[17][12426]<<","<<raw_data[3863977][0]<<endl;
	for(i = 0; i < raw_lines; i++)
	{
		//if(i%10000 == 0)
		//	cout<<i<<"/"<<raw_lines<<endl;
	    ind1 = int(raw_data[i][0]/resolution);
		ind2 = int(raw_data[i][1]/resolution);
        //if(i >= 3863976)
        {
            //cout<<i<<endl;
            //cout<<raw_data[i][0]<<endl;
            //cout<<raw_data[i][1]<<endl;
            //cout<<ind1<<","<<ind2<<endl;
            //cout<<raw_data[i][2]<<endl;
        }
		Contact_Matrix[ind1][ind2] = raw_data[i][2];
		Contact_Matrix[ind2][ind1] = raw_data[i][2];
	}
	cout<<"\nfinished creating contact matrix";
  //store the big contact matrix in a file
  ofstream whole_matrix(output_big_contact_matrix_path);
	for(i = 0; i < max_ind; i++)
	{
		for(j = 0; j < max_ind; j++)
		{
			if(j < max_ind-1)
				whole_matrix<<Contact_Matrix[i][j]<<",";
			else
                if(i<max_ind-1)
                    whole_matrix<<Contact_Matrix[i][j]<<"\n";
                else
                    whole_matrix<<Contact_Matrix[i][j];
                
		}
	} 
	whole_matrix.close();
	cout<<"\nfinished writing contact matrix";
  //build the hi-c matrix at the tads level
	int int_ind;
	for(i = 0; i < max_ind; i++)
	{
		ind1 = i*resolution;
		for(j = 0; j < max_ind; j++)
		{
			ind2 = j*resolution;
			int flag1 = 0, flag2 = 0;
			for(int_ind = 0; int_ind < n_tads; int_ind++)
			{
				if(ind1>=tads[int_ind][0] && ind1<tads[int_ind][1])
				{
					row_final = int_ind;
					flag1 = 1;
					break;
				}
			}
			for(int_ind = 0; int_ind < n_tads; int_ind++)
			{
				if(ind2>=tads[int_ind][0] && ind2<tads[int_ind][1])
				{
					col_final = int_ind;
					flag2 = 1;
					break;
				}
			}
			if(flag1 == 1 && flag2 ==1)
			{
				hic_matrix[row_final][col_final]+=Contact_Matrix[i][j];
			}
		}
	}
	////cout<<"\nfinished creating tad level matrix";
	//normalize the hic matrix by dividing by number of blocks
	for(i = 0; i < n_tads; i++)
	{
		for(j = 0; j < n_tads; j++)
		{
			hic_matrix[i][j]/=(tads[i][2]*tads[j][2]);
			if(i == j)
				hic_matrix[i][j] = 0;
		}
	}
	////cout<<"\nfinished normalizing hic matrix";
	//int ind1, ind2;
	
	//ofstream HiC_file(output_HiC_matrix_tad_level_path);
	
	//store into files
    ////cout<<"\n n_tads = "<<n_tads<<endl;
	for(i = 0; i < n_tads; i++)
	{
		for(j = 0; j < n_tads-1; j++)
		{
		  f_out_tads<<hic_matrix[i][j]<<",";
	  }
		f_out_tads<<hic_matrix[i][j]<<"\n";
	}
	f_out_tads.close();
	////cout<<"\nfinished writing tad level matrix";
	ofstream loci_file(output_loci_file_tad_level_path);
	for(i = 0; i < n_tads; i++)
	{
		loci_file<<round((tads[i][0]+tads[i][1])/2)<<"\n";
	}
	loci_file.close();
	////cout<<"\nfinished writing loci tad level matrix";
	char filename[70];
	int min_i, max_i, i1, i2;
	for(i = 0; i<n_tads; i++)
	{
	    ////cout<<"\nlocal tad #"<<i<<endl;
		sprintf(filename,"%s/hic_matrix_tad_%d_Rao_%dkb.txt",output_files_path,i, resolution/1000);
		ofstream out_tad(filename);
		min_i = tad_indexes[i][0];
		max_i = tad_indexes[i][1];
		for(i1 = min_i; i1 <= max_i; i1++)
		{
			for(i2 = min_i; i2 <= max_i; i2++)
			{	
				if(i1 == i2 && i1 != max_i)
				{
					out_tad<<0<<",";
					continue;
				}
				if(i1 == i2 && i1 == max_i)
				{
					out_tad<<0<<"\n";
					continue;
				}					
				if(i2 < max_i)
					out_tad<<Contact_Matrix[i1][i2]<<",";
				else
					out_tad<<Contact_Matrix[i1][i2]<<"\n";
			}
		}
		out_tad.close();
		sprintf(filename,"%s/loci_tad_%d_Rao_%dkb.txt",output_files_path,i, resolution/1000);
		ofstream out_loci(filename);
		int l = tads[i][0];
		for(i1 = min_i; i1<=max_i; i1++)
		{
			out_loci<<l<<"\n";
			l+=resolution;
		}
		out_loci.close();
	}
        return 0;
}

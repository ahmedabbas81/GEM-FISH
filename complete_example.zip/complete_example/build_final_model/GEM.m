function [C1, structure]=GEM(HiC_file,loci_file,max_iter,M,lambdaE,infer_latent,input_sizepara,lambdaR,g_s_exp,out_directory,v_original,size_original,g_length_original,g_length_current,slope)

% ----------------------- Overview ------------------------ %
% Main function for GEM                                     %
% --------------------------------------------------------- %
% HIC_file: File name of Hi-C map                           %
% loci_file: File name of genomic loci                      %
% max_iter: Maximum number of iterations                    %
% M: Number of conformations                                %
% lambdaE: Energy coefficient                               %
% infer_latent: Whether to infer the latent function (1/0)  %
% input_sizepara: Packing density provided by user.         %
%               -1 means using the estimated value by GEM.  %
% --------------------------------------------------------- %


% ---------------------- Preproccess ---------------------- %
% Data Preprocess before modeling.                          %
% --------------------------------------------------------- %
% X: Hi-C map                                               %
% loci: Genomic loci                                        %
% sizepara: Packing density                                 %
% index: The index of the genomic loci of interest          %
% --------------------------------------------------------- %
[ X,loci,sizepara,index ] = Preprocess(HiC_file,loci_file,input_sizepara);


% ---------------------- Optimizer ------------------------ %
% An optimization process that considers both Hi-C data     %
% and conformation energy.                                  %
% --------------------------------------------------------- %
% structure: The reconstructed ensemble of conformations    %
%            (N*3*M matrix)                                 %
% proportions: The corresponding weights of conformations   %
% C: Total cost (C1+lambda_E*C2)                            %
% C1: Data cost (KL divergence)                             %
% C2: Energy cost (Conformation energy)                     %
% --------------------------------------------------------- %
v_estimated = v_original*(g_length_current/g_length_original);
sizes_ratio = (v_estimated/v_original)^(1/3);      %sizes_ratio = size_estimated/size_original
size_estimated = sizes_ratio*size_original;
rg_estimated = size_estimated/slope;
rg_expected_sq = rg_estimated^2


[structure,proportions,C,C1,C2,C3]=Optimizer(X,loci,max_iter,sizepara,M,lambdaE,index,lambdaR,rg_expected_sq,g_s_exp);


disp('============================ RESULTS ============================');

%The conformations all have been aligned using the singular value decomposition (SVD) algorithm
if M>1
    for i=1:M
        [ RMSE,structure(:,:,i) ] = SVD3D( structure(:,:,i),structure(:,:,1) );
    end
end
% Output reconstructed structure to 'conformation[1-M].txt'
for m=1:M
    dlmwrite(['./' out_directory '/conformation' num2str(m) '.txt'],structure(:,:,m),'delimiter', '\t','precision','%6.4f');
end

% Output the corresponding weights of conformations to 'proportions.txt'
dlmwrite(['./' out_directory '/proportions.txt'],proportions,'delimiter', '\t','precision','%6.4f');
filename = sprintf('./%s/results.txt',out_directory);
fid = fopen(filename,'w');
fprintf(fid,'Total cost (C): %.3f\n',C);
fprintf(fid,'Hi-C cost (C1): %.3f\n',C1);
fprintf(fid,'Energy cost (C2): %.3e\n',C2);
fprintf(fid,'FISH cost (C3): %.3e\n',C3);


disp (['Total cost (C): ' num2str(C)]);
disp (['Hi-C cost (C1): ' num2str(C1)]);
disp (['Energy cost (C2): ' num2str(C2)]);
disp (['FISH cost (C3): ' num2str(C3)]);
disp (['The reconstructed conformations and the conformation weights are written to ''conformation[1-' num2str(M) '].txt'' and ''proportions.txt'', respectively. ' ]);

% ------------------- Latent function  -------------------- %
% Capture the latent function by comparing the modeled      %
% structures with the original Hi-C data.                   %
% --------------------------------------------------------- %
if infer_latent==1
    LatentFunction( X(index,index),structure,M,proportions );
end

disp('=================================================================');



end

function box_plotting(B2_B2_dist,B2_B1_dist,filename)
C = [B2_B2_dist/1000.0;B2_B1_dist/1000.0];
G1 = zeros(size(B2_B2_dist,1),1);
G2 = ones(size(B2_B1_dist,1),1);
G = [G1;G2];
figure,
h = boxplot(C,G);%,'plotstyle','compact');
ylabel('Spatial distance (\mum)');%,'FontSize',20);
% xl = sprintf('Chr%s',chr_num_string)
% xlabel(xl);
color = ['c','m'];
%hLegend = legend(findall(gca,'Tag','Box'), {'Group A','Group B','Group C'});
%legend(h,{'regular enhancers','super enhancers'})
set(gca,'xticklabel',{'Same subcomp.','Diff. subcomp.'},'FontSize',16)
%ylim([min(C20)-min(C20)*0.1 max(C20)+max(C20)*0.1]);

H = sigstar({[1,2]},0.04,max(C));

h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
end
color = ['c','m'];
c = get(gca, 'Children');
set(gca, 'FontSize', 16)
fig=gcf;
% fig.Units='normalized';
% fig.OuterPosition=[0 0 0.25 0.35];
%filename = sprintf('boxplot_enhancers.fig');
saveas(gcf,filename);
%clear all
out_dir = 'chr20_final_model'
mkdir(out_dir);
chr_num_string = '20';
ntads = 30;
% Spatial = a * genomic^b
% For Chr20 a = 0.086, and b = 0.17
a = 0.086;
b = 0.17;
%Spatial = (Hi-C frequency)^-0.25 --> hic_exp = -0.25
hic_exp = -0.25;
%we are using resolution 5 Kbp for the individual TADs 3D models
resolution = 5E3;
tic
get_high_res_and_test_Rao(chr_num_string,ntads,a,b,resolution,out_dir,hic_exp);
toc

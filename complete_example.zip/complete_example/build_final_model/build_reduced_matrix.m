function [d_prior,reduced_positions]=build_reduced_matrix(whole_hic_matrix,tad_positions,resolution,a_coef,g_s_exp,hic_exp,fish_distances)
ntads=size(tad_positions,1);
row = 1;
for i = 1 : ntads-1
    endI = tad_positions(i,2);
    start_next_I = tad_positions(i+1,1);
%    centerI = (startI+endI)/2;
    indexi_End = ceil(endI*1.0/resolution);
    index_nextI_start = ceil(start_next_I*1.0/resolution);
    if(index_nextI_start == indexi_End)
        index_nextI_start = index_nextI_start + 1;
    end
    if(start_next_I - endI == 0)
        d_prior(i) = resolution/130;

    elseif(whole_hic_matrix(indexi_End,index_nextI_start)~=0)
        f = whole_hic_matrix(indexi_End,index_nextI_start);
        d_prior(i) = 1000 * f^hic_exp;
    else
        gdist = (index_nextI_start-indexi_End)*resolution;
        d_prior(i) = a_coef*1000*(gdist)^g_s_exp;
    end
end
for i = 1 : ntads
    startI = tad_positions(i,1);
    endI = tad_positions(i,2);
    centerI = (startI+endI)/2;
    if(mod(startI,resolution)==0)
        indexi_Start=(startI/resolution)+1;
    else
        indexi_Start = ceil(startI*1.0/resolution);
    end
    indexi_End = ceil(endI*1.0/resolution);
    for i1 = indexi_Start : indexi_End
        col = 1;
        for j = 1 : ntads
            startJ = tad_positions(j,1);
            endJ = tad_positions(j,2);
            centerJ = (startJ + endJ)/2;
            if(mod(startJ,resolution)==0)
                indexj_Start=(startJ/resolution)+1;
            else
                indexj_Start = ceil(startJ*1.0/resolution);
%                 if(indexj_Start == indexi_End)
%                     indexj_Start = indexj_Start + 1;
%                 end
            end
            indexj_End = ceil(endJ*1.0/resolution);
            
        end
        reduced_indices(row) = i1;
        reduced_positions(row,1) = (i1-1)*resolution;
        reduced_positions(row,2) = i1*resolution - 1;
        row = row + 1;
    end
end
for i=1:row-1
    for j=1:col-1
        if(reduced_matrix(i,j)~=reduced_matrix(j,i))
            fprintf('\nerror at %d,%d\n',i,j);
        end
    end
end

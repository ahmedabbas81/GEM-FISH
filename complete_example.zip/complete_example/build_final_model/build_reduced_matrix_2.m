function [reduced_matrix,estimated_distances,d_prior,reduced_positions,reduced_indices]=build_reduced_matrix_2(whole_hic_matrix,tad_positions,resolution,a_coef,g_s_exp,hic_exp,fish_distances)
fid = fopen('xa_reduced_item.txt','w');
ntads=size(tad_positions,1);
row = 1;
% for i = 1 : ntads
%     startI = tad_positions(i,1);
%     endI = tad_positions(i,2);
%     if(mod(startI,resolution)==0)
%         indexi_Start=(startI/resolution)+1;
%     else
%         indexi_Start = ceil(startI*1.0/resolution);
%     end
%     indexi_End = ceil(endI*1.0/resolution);
%     tads_positions(i,3) = indexi_Start;
%     tads_positions(i,4) = indexi_End;
for i = 1 : ntads-1
    endI = tad_positions(i,2);
    start_next_I = tad_positions(i+1,1);
    centerI = (startI+endI)/2;
    indexi_End = ceil(endI*1.0/resolution);
    index_nextI_start = ceil(start_next_I*1.0/resolution);
    if(index_nextI_start == indexi_End)
        index_nextI_start = index_nextI_start + 1;
    end
    if(whole_hic_matrix(indexi_End,index_nextI_start)~=0)
        f = whole_hic_matrix(indexi_End,index_nextI_start);
        d_prior(i) = 1000 * f^hic_exp;
    else
        gdist = (index_nextI_start-indexi_End)*resolution;
        d_prior(i) = a_coef*1000*(gdist)^g_s_exp;
    end
end


    d_prior(i)=1000*reduced_matrix(row,col)^hic_exp;
                     if(d_prior(i) < 100)
                        fprintf('%f, %d, %d\n',a_coef,row,col);
                     end
                    elseif(j==i+1 && j1==indexj_Start && i1 == indexi_End && reduced_matrix(row,col)==0)
                       if(estimated_distances(row,col) == 0)
                           d_prior(i) = 200;
                           fprintf(fid,'%d, %d, %d, %d, %f',row,col,i1,j1,reduced_matrix(row,col));
                           
                       else
                            d_prior(i)=estimated_distances(row,col);
                       end
                       if(d_prior(i) < 100)
                            fprintf('%f, %d, %d\n',a_coef,row,col);
                       end
    for i1 = indexi_Start : indexi_End
        col = 1;
        for j = 1 : ntads
            startJ = tad_positions(j,1);
            endJ = tad_positions(j,2);
            centerJ = (startJ + endJ)/2;
            if(mod(startJ,resolution)==0)
                indexj_Start=(startJ/resolution)+1;
            else
                indexj_Start = ceil(startJ*1.0/resolution);
%                 if(indexj_Start == indexi_End)
%                     indexj_Start = indexj_Start + 1;
%                 end
            end
            indexj_End = ceil(endJ*1.0/resolution);
            for j1 = indexj_Start : indexj_End
                reduced_matrix(row,col) = whole_hic_matrix(i1, j1);
                estimated_distances(row,col) = a_coef*1000*((abs(i1 - j1)*resolution))^g_s_exp;
                if(j==i+1 && j1==indexj_Start && i1 == indexi_End && reduced_matrix(row,col)~=0)
                    d_prior(i)=1000*reduced_matrix(row,col)^hic_exp;
                     if(d_prior(i) < 100)
                        fprintf('%f, %d, %d\n',a_coef,row,col);
                     end
                    elseif(j==i+1 && j1==indexj_Start && i1 == indexi_End && reduced_matrix(row,col)==0)
                       if(estimated_distances(row,col) == 0)
                           d_prior(i) = 200;
                           fprintf(fid,'%d, %d, %d, %d, %f',row,col,i1,j1,reduced_matrix(row,col));
                           
                       else
                            d_prior(i)=estimated_distances(row,col);
                       end
                       if(d_prior(i) < 100)
                            fprintf('%f, %d, %d\n',a_coef,row,col);
                       end
                end
%                 if(j == i+1 && j1 == indexj_Start && i1 == indexi_End)
%                     d_prior(i) = (abs(i1 - j1)*resolution)*fish_distances(i,j)/abs(centerI-centerJ);
%                 end
                col = col + 1;
            end
        end
        reduced_indices(row) = i1;
        reduced_positions(row,1) = (i1-1)*resolution;
        reduced_positions(row,2) = i1*resolution - 1;
        row = row + 1;
    end
end
row
col
for i=1:row-1
    for j=1:col-1
        if(reduced_matrix(i,j)~=reduced_matrix(j,i))
            fprintf('\nerror at %d,%d\n',i,j);
        end
    end
end
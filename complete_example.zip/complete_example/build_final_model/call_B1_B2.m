B_tads_22 = [1,2,6,7,8,9,13,14,24,26]; %%chr22
B_tads_20 = [1,4,5,7,9,10,11,12,18,19,20,20,25,26,27,28]; %%chr20
B_tads_21 = [1,2,3,4,5,6,7,10,11,12,13,14,15,23,24,25,26,27,28];%chr20
dir_name = 'sub-comp-cmm_Sept7';
mkdir(dir_name);
[h_r_str_20,comp_20,s1_20,s2_20,positions_20,scores_b1_20,scores_b2_20] = call_getB1_B2_new(20,30,B_tads_20);
write_cmm_subcomp(comp_20,positions_20,s1_20,s2_20,dir_name,'20',h_r_str_20);
[h_r_str_22,comp_22,s1_22,s2_22,positions_22,scores_b1_22,scores_b2_22] = call_getB1_B2_new(22,27,B_tads_22);
write_cmm_subcomp(comp_22,positions_22,s1_22,s2_22,dir_name,'22',h_r_str_22);
[h_r_str_21,comp_21,s1_21,s2_21,positions_21,scores_b1_21,scores_b2_21] = call_getB1_B2_new(21,34,B_tads_21);
write_cmm_subcomp(comp_21,positions_21,s1_21,s2_21,dir_name,'21',h_r_str_21);
save('sub_comp_B1_B2_hr_structures.mat','h_r_str_20','h_r_str_21','h_r_str_22','scores_b1_20','scores_b2_20','scores_b1_21','scores_b2_21','scores_b1_22','scores_b2_22');


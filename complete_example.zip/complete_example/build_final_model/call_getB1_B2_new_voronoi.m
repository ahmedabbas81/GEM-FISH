function [h_r_structure] = call_getB1_B2_new_voronoi(chr_num,last_tad,B_tads)
f1 = sprintf('./All_bed_txt_files/H3K27me3_discrete_%d_50kb.csv',chr_num);
H3K27me3_file = csvread(f1);
f1 = sprintf('./All_bed_txt_files/H3K27ac_discrete_%d_50kb.csv',chr_num);
H3K27ac_file = csvread(f1);
f1 = sprintf('./All_bed_txt_files/H3K79me2_discrete_%d_50kb.csv',chr_num);
H3K79me2_file = csvread(f1);
f1 = sprintf('./All_bed_txt_files/H3K4me1_discrete_%d_50kb.csv',chr_num);
H3K4me1_file = csvread(f1);

f2 = sprintf('./All_bed_txt_files/H3K36me3_discrete_%d_50kb.csv',chr_num);
H3K36me3_file = csvread(f2);
useful_entries = H3K27me3_file(H3K27me3_file(:,3)>0,:);
% useful_entries = useful_entries(useful_entries(:,1)>14350000,:);
% useful_entries = useful_entries(useful_entries(:,1)<42000000,:);
% fid = fopen('H3K34me3_hg19.bed','w');
% for i = 1 : size(useful_entries,1)
%     fprintf(fid,'chr20:%d-%d\n',useful_entries(i,1),useful_entries(i,2));
% end
% H3K34_hg18 = load('./chr20_sub_comp/H3K34me3_hg18_5kb.txt');
H3K27_hg19 = useful_entries;

useful_entries = H3K36me3_file(H3K36me3_file(:,3)>0,:);
H3K36_hg19 = useful_entries;

useful_entries = H3K4me1_file(H3K4me1_file(:,3)>0,:);
H3K4me1_hg19 = useful_entries;
useful_entries = H3K79me2_file(H3K79me2_file(:,3)>0,:);
H3K79me2_hg19 = useful_entries;
useful_entries = H3K27ac_file(H3K27ac_file(:,3)>0,:);
H3K27ac_hg19 = useful_entries;


tads_positions_path=sprintf('/home/ahmed/Rao_data/tads_chr%d_hg19.txt',chr_num);
tads_p = load(tads_positions_path);
first_tad = 1;
%last_tad = 30;
%B_tads = [1,2,6,7,8,9,13,14,24,26]; %%chr22
%B_tads = [1,4,5,7,9,10,11,12,18,19,20,20,25,26,27,28]; %%chr20
%B_tads = [1,2,3,4,5,6,7,10,11,12,13,14,15,23,24,25,26,27,28];%chr20
dir_name = sprintf('chr%d_sub_comp_jan22',chr_num);
mkdir(dir_name);
%[h_r_structure,comp,size_b1,size_b2,positions,reduced_positions,scores_b1,scores_b2] = getB1_B2_new(H3K27_hg19,H3K36_hg19,H3K27ac_hg19,H3K79me2_hg19,H3K4me1_hg19,first_tad,last_tad,tads_p,chr_num,dir_name,B_tads);
[h_r_structure,comp,size_b1,size_b2,positions,reduced_positions,scores_b1,scores_b2,scores_A1] = getB1_B2_new_voronoi(H3K27_hg19,H3K36_hg19,H3K27ac_hg19,H3K79me2_hg19,H3K4me1_hg19,first_tad,last_tad,tads_p,chr_num,dir_name,B_tads);
str_3d = h_r_structure(:,1:3);
[V,C] = voronoin(str_3d);
s = CStack();
s_index = CStack();%c is a cells, and could be omitted 
% s.size() return the numble of element 
% s.empty() return whether the stack is empty 
% s.push(el) push el to the top of stack 
% s.pop() pop out the top of the stack, and return the element 
% s.top() return the top element of the stack 
% s.remove() remove all the elements in the stack 
% s.content() return all the data of the stack (in the form of a 
% cells with size [s.size(), 1]
label_b1 = 100;
label_b2 = 1000;
for i = 1 : length(C)
    %cell_vert = C(i);
    if(h_r_structure(i,5) == 10)
        s.push(C(i));
        s_index.push(num2cell(i));
        h_r_structure(i,5) = 0;
        [h_r_structure,label_b2] = loop_and_push(C,s,s_index,h_r_structure,label_b2,10,1);
        label_b2 = label_b2+1;
    elseif(h_r_structure(i,5) == -10)
        s.push(C(i));
        s_index.push(num2cell(i));
        h_r_structure(i,5) = 0;
        [h_r_structure,label_b1] = loop_and_push(C,s,s_index,h_r_structure,label_b1,-10,1);
        label_b1 = label_b1+1;
    end
end
h_r_structure(:,7:8) = reduced_positions(:,1:2); 

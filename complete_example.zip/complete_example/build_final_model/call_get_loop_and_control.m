l_file = '/home/Ahmed/gem-master-local/chr_22_outputs_Nov2-afternoon_New2/using_square_difference/loop_distances_classified.csv';
c_file = '/home/Ahmed/gem-master-local/chr_22_outputs_Nov2-afternoon_New2/using_square_difference/control_distances.csv';
dir_name = 'ch22';
mkdir(dir_name);
get_loops_and_controls(l_file,c_file,dir_name);

l_file = '/home/Ahmed/gem-master-local/chr_21_outputs_Nov1/using_square_difference/loop_distances_classified.csv';
c_file = '/home/Ahmed/gem-master-local/chr_21_outputs_Nov1/using_square_difference/control_distances.csv';
dir_name = 'ch21';
mkdir(dir_name);
get_loops_and_controls(l_file,c_file,dir_name);

l_file = '/home/Ahmed/gem-master-local/chr_20_outputs_Nov2-afternoon_New2/using_square_difference/loop_distances_classified.csv';
c_file = '/home/Ahmed/gem-master-local/chr_20_outputs_Nov2-afternoon_New2/using_square_difference/control_distances.csv';
dir_name = 'ch20';
mkdir(dir_name);
get_loops_and_controls(l_file,c_file,dir_name);

l_file = '/home/Ahmed/gem-master-local/chr_Xa_outputs_Nov1/using_square_difference/loop_distances_classified.csv';
c_file = '/home/Ahmed/gem-master-local/chr_Xa_outputs_Nov1/using_square_difference/control_distances.csv';
dir_name = 'chXa';
mkdir(dir_name);
get_loops_and_controls(l_file,c_file,dir_name);

l_file = '/home/Ahmed/gem-master-local/chr_Xi_outputs_Nov1/using_square_difference/loop_distances_classified.csv';
c_file = '/home/Ahmed/gem-master-local/chr_Xi_outputs_Nov1/using_square_difference/control_distances.csv';
dir_name = 'chXi';
mkdir(dir_name);
get_loops_and_controls(l_file,c_file,dir_name);
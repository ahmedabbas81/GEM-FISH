function draw_diagonal(diag_low_res, diag_high_res,dir_name, file_name)
bottom = min(min(diag_high_res),min(diag_low_res));
top = max(max(diag_high_res),max(diag_low_res));
figure('units','normalized','outerposition',[0 0 0.15 0.6])
subplot(1,2,1)
set(gca, 'units','normalized','OuterPosition', [0, 0, 0.2, 1])
imagesc(diag_low_res');
set(gca,'xtick',[])
set(gca,'xticklabel',[])
colormap(redblue)
caxis manual
caxis([bottom top])
handle = subplot(1,2,2)
set(gca, 'units','normalized','OuterPosition', [0.3, 0, 0.2, 1])
imagesc(diag_high_res');
set(gca,'xtick',[])
set(gca,'xticklabel',[])
colormap(redblue)
caxis manual
caxis([bottom top])
p = get(handle,'position');
colorbar('location','Manual','position', [p(1)+p(3)+0.1 p(2) 0.05 p(4)]);
filename = sprintf('./%s/%s.fig',dir_name,file_name);
saveas(gcf,filename); 
filename = sprintf('./%s/%s.png',dir_name,file_name);
saveas(gcf,filename); 
close
% l2 and c2 are 1 row and many elements in it
clear all
dir_name = 'common_figures'
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_20_outputs/using_square_difference/loops_and_controls.mat';
load(filename)
loops_20 = l2;
controls_20 = c2;
max1(1) = max(quantile(l2,0.8)*2,quantile(c2,0.8)*2);
min1(1) = min(min(loops_20),min(controls_20));
clear l2 c2
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_21_outputs/using_square_difference/loops_and_controls.mat';
load(filename)
loops_21 = l2;
controls_21 = c2;
max1(2) = max(quantile(l2,0.8)*2,quantile(c2,0.8)*2);
min1(2) = min(min(loops_21),min(controls_21));

clear l2 c2
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_22_outputs/using_square_difference/loops_and_controls.mat';
load(filename)
loops_22 = l2;
controls_22 = c2;
max1(3) = max(quantile(l2,0.8)*2,quantile(c2,0.8)*2);
min1(3) = min(min(loops_22),min(controls_22));

clear l2 c2
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_Xa_outputs/using_square_difference/loops_and_controls.mat';
load(filename)
loops_Xa = l2;
controls_Xa = c2;
max1(4) = max(quantile(l2,0.8)*2,quantile(c2,0.8)*2);
min1(4) = min(min(loops_Xa),min(controls_Xa));

clear l2 c2
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_Xi_outputs/using_square_difference/loops_and_controls.mat';
load(filename)
loops_Xi = l2;
controls_Xi = c2;
max1(5) = max(quantile(l2,0.8)*2,quantile(c2,0.8)*2);
min1(5) = min(min(loops_Xi),min(controls_Xi));

clear l2 c2
k = 1;
grp = 0;
for i = 1 : size(loops_20,2)
    C(k) = loops_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_20,2)
    C(k) = controls_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_21,2)
    C(k) = loops_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_21,2)
    C(k) = controls_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_22,2)
    C(k) = loops_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_22,2)
    C(k) = controls_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_Xa,2)
    C(k) = loops_Xa(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_Xa,2)
    C(k) = controls_Xa(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_Xi,2)
    C(k) = loops_Xi(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_Xi,2)
    C(k) = controls_Xi(1,i);
    grouping(k) = grp;
    k = k + 1;
end

max_all = max(max1);
min_all = min(min1);
%boxplot(C,grp,'labels',{'loop distances','control distances'},'symbol','');
%boxplot(C,grouping,'labels',{'loop distances','control distances'},'symbol','')
figure('units','normalized','outerposition',[0 0 1 0.6]);
positions = [1 1.25 2 2.25 3 3.25 4 4.25 5 5.25];
boxplot(C,grouping, 'positions', positions,'symbol','');
ylabel('Packing density (kb/nm)');
set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6)) mean(positions(7:8)) mean(positions(9:10))])
set(gca,'xticklabel',{'Chr20','Chr21','Chr22','ChrXa','ChrXi'})
%H = sigstar({[1,2], [3,4], [5,6], [7,8], [9,10]},[0.01,0.01,0.01,0.01,0.01]);
yt = get(gca, 'YTick');
axis([xlim    0  ceil(max(yt)*1.2)])
xt = get(gca, 'xtick');
% hold on
% plot(xt([1]), max(yt)*1.15, '*k')
% hold off
color = ['c', 'y', 'c', 'y','c', 'y', 'c', 'y','c','y'];
h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
end

c = get(gca, 'Children');

hleg1 = legend(c(1:2), 'Loops packing density', 'Controls packing density' );
ylim([0 max_all]);
%set(H,'color','r')
% Density_A is a column vector
clear all
dir_name = 'ChrX_figures_Final_en_Shaa_Allah';
mkdir(dir_name)
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xa_outputs/using_square_difference/structures_and_stats.mat';
load(filename)
V_Xa = volumes_ind*1E-9;%volume in um^3
clear volumes_ind
GL_Xa = GL_ind*1E-6;%genomic length in Mb
density_Xa = GL_Xa./V_Xa;
clear GL_ind;
g_structure_Xa = global_structure;
g_structure_Xa_2D(:,1) = g_structure_Xa(:,1);
g_structure_Xa_2D(:,2) = g_structure_Xa(:,3);
h_r_structure_Xa = high_resolution_structure;
h_r_structure_Xa_2D(:,1) = h_r_structure_Xa(:,1);
h_r_structure_Xa_2D(:,2) = h_r_structure_Xa(:,3);
clear global_structure high_resolution_structure
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xa_outputs/using_square_difference/fish+hic_2D_XZ.mat';
load(filename)
k1_Xa = k1;
k2_Xa = k2;
x1_Xa = x1;
x2_Xa = x2;
y1_Xa = y1;
y2_Xa = y2;
k1_Xa = convhull(x1_Xa,y1_Xa);
k2_Xa = convhull(x2_Xa,y2_Xa);
clear k1 k2 x1 x2 y1 y2

loops_20 = density_Xa';
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xa_outputs/using_square_difference/compartments.mat';
load(filename)
X1_F_A = X1_F;
X2_F_A = X2_F;
clear X1_F X2_F
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xi_outputs/using_square_difference/structures_and_stats.mat';
load(filename)
V_Xi = volumes_ind*1E-9;%volume in um^3
clear volumes_ind
GL_Xi = GL_ind*1E-6;%genomic length in Mb
density_Xi = GL_Xi./V_Xi;
clear GL_ind;
g_structure_Xi = global_structure;
g_structure_Xi_2D(:,1) = g_structure_Xi(:,1);
g_structure_Xi_2D(:,2) = g_structure_Xi(:,3);

h_r_structure_Xi = high_resolution_structure;
h_r_structure_Xi_2D(:,1) = h_r_structure_Xi(:,1);
h_r_structure_Xi_2D(:,2) = h_r_structure_Xi(:,3);
clear global_structure high_resolution_structure
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xi_outputs/using_square_difference/fish+hic_2D_XZ.mat';
load(filename)
x1_Xi = x1;
x2_Xi = x2;
y1_Xi = y1;
y2_Xi = y2;
k1_Xi = convhull(x1_Xi,y1_Xi);
k2_Xi = convhull(x2_Xi,y2_Xi);
clear k1 k2 x1 x2 y1 y2
controls_20 = density_Xi';
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xi_outputs/using_square_difference/compartments.mat';
load(filename)
X1_F_I = X1_F;
X2_F_I = X2_F;
clear X1_F X2_F
[p1,h1] = ranksum(density_Xa,density_Xi,'tail','left');
k = 1;
grp = 0;
for i = 1 : size(loops_20,2)
    C(k) = loops_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_20,2)
    C(k) = controls_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
% Xa_11 = x1_Xa(k1_Xa);
% Ya_11 = y1_Xa(k1_Xa);
% Xa_22 = x2_Xi(k2_Xa);
% Ya_22 = y2_Xi(k2_Xa);
%file_name=sprintf('%s/high_res_structure.fig',dir_name);
%fullfig,
figure,
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.6]);

% subplot(1,2,1)
% plot3(g_structure_Xa(:,1),g_structure_Xa(:,2),g_structure_Xa(:,3),'*- k','LineWidth',1.5);
% hold on
% plot3(h_r_structure_Xa(:,1),h_r_structure_Xa(:,2),h_r_structure_Xa(:,3),'x- c','LineWidth',0.5);
% xlim([min(g_structure_Xa(:,1) - 100) max(g_structure_Xa(:,1) + 100)])
% ylim([min(g_structure_Xa(:,2) - 100) max(g_structure_Xa(:,2) + 100)])
% zlim([min(g_structure_Xa(:,3) - 100) max(g_structure_Xa(:,3) + 100)])
% hold off
% title('A')
% subplot(1,2,2)
% plot3(g_structure_Xi(:,1),g_structure_Xi(:,2),g_structure_Xi(:,3),'*- k','LineWidth',1.5);
% hold on
% plot3(h_r_structure_Xi(:,1),h_r_structure_Xi(:,2),h_r_structure_Xi(:,3),'x- c','LineWidth',0.5);
% hold off
% xlim([min(g_structure_Xa(:,1) - 100) max(g_structure_Xa(:,1) + 100)])
% ylim([min(g_structure_Xa(:,2) - 100) max(g_structure_Xa(:,2) + 100)])
% zlim([min(g_structure_Xa(:,3) - 100) max(g_structure_Xa(:,3) + 100)])
% title('B')
subplot(1,2,1)
plot(g_structure_Xa_2D(:,1),g_structure_Xa_2D(:,2),'*- k','LineWidth',1.5);
hold on
plot(h_r_structure_Xa_2D(:,1),h_r_structure_Xa_2D(:,2),'x- c','LineWidth',0.5);
xlim([min(h_r_structure_Xa_2D(:,1) - 100) max(h_r_structure_Xa_2D(:,1) + 100)])
ylim([min(h_r_structure_Xa_2D(:,2) - 100) max(h_r_structure_Xa_2D(:,2) + 100)])
hold off
title('A')
subplot(1,2,2)
plot(g_structure_Xi_2D(:,1),g_structure_Xi_2D(:,2),'*- k','LineWidth',1.5);
hold on
plot(h_r_structure_Xi_2D(:,1),h_r_structure_Xi_2D(:,2),'x- c','LineWidth',0.5);
hold off
xlim([min(h_r_structure_Xa_2D(:,1) - 100) max(h_r_structure_Xa_2D(:,1) + 100)])
ylim([min(h_r_structure_Xa_2D(:,2) - 100) max(h_r_structure_Xa_2D(:,2) + 100)])
%zlim([min(g_structure_Xa(:,3) - 100) max(g_structure_Xa(:,3) + 100)])
title('B')
filename = sprintf('%s/structures.fig',dir_name);
saveas(gcf,filename);
close
figure,
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.6]);
subplot(1,2,1)
bar(X1_F_A,'r');
hold
bar(X2_F_A,'b');
xlim([0 size(X1_F_A,1)+1])
max_limit = max(X1_F_A);
min_limit = min(X2_F_A);
ylim([min_limit-0.02 max_limit+0.02])
xlabel('TAD #')
ylabel('Principal component coefficient')
title('C')
subplot(1,2,2)
bar(X1_F_I,'r');
hold
bar(X2_F_I,'b');
xlim([0 size(X1_F_I,1)+1])
max_limit = max(X1_F_I);
min_limit = min(X2_F_I);
ylim([min_limit-0.02 max_limit+0.02])
xlabel('TAD #')
ylabel('Principal component coefficient')
title('D')
filename = sprintf('%s/compartments.fig',dir_name);
saveas(gcf,filename);
close
figure,
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.6]);
subplot(1,2,1)
plot(x1_Xa(k1_Xa),y1_Xa(k1_Xa),'c-',x1_Xa,y1_Xa,'b*')
hold
plot(x2_Xa(k2_Xa),y2_Xa(k2_Xa),'m-',x2_Xa,y2_Xa,'ro')
hold off
title('E')
subplot(1,2,2)
plot(x1_Xi(k1_Xi),y1_Xi(k1_Xi),'c-',x1_Xi,y1_Xi,'b*')
hold on
plot(x2_Xi(k2_Xi),y2_Xi(k2_Xi),'m-',x2_Xi,y2_Xi,'ro')
hold off
title('F')
filename = sprintf('%s/polarization_index.fig',dir_name);
saveas(gcf,filename);
close

figure,
boxplot(C,grouping,'symbol','');
ylabel('Density (Mb/\mum^3)')
set(gca,'xticklabel',{'ChrXa','ChrXi'})
H = sigstar({[1,2]},[0.04]);
color = ['c', 'y'];
h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
end

c = get(gca, 'Children');

%hleg1 = legend(c(1:2), 'Xa TAD density', 'Xi TAD density' );
%ylim([0 max_all]);
set(H,'color','r')
title('E')
filename = sprintf('%s/density.fig',dir_name);
saveas(gcf,filename);
close


% Density_A is a column vector
clear all
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_20_outputs/using_square_difference/densities.mat';
load(filename)
loops_20 = Density_A';
controls_20 = Density_B';
max1(1) = max(quantile(Density_A,0.8)*2,quantile(Density_B,0.8)*2);
min1(1) = min(min(loops_20),min(controls_20));
clear Density_A Density_B
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_21_outputs/using_square_difference/densities.mat';
load(filename)
loops_21 = Density_A';
controls_21 = Density_B';
max1(2) = max(quantile(Density_A,0.8)*2,quantile(Density_B,0.8)*2);
min1(2) = min(min(loops_21),min(controls_21));

clear Density_A Density_B
filename = '/home/Ahmed/gem-master-local/Nov-20-night/chr_22_outputs/using_square_difference/densities.mat';
load(filename)
loops_22 = Density_A';
controls_22 = Density_B';
max1(3) = max(quantile(Density_A,0.8)*2,quantile(Density_B,0.8)*2);
min1(3) = min(min(loops_22),min(controls_22));

clear Density_A Density_B

k = 1;
grp = 0;
for i = 1 : size(loops_20,2)
    C(k) = loops_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_20,2)
    C(k) = controls_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_21,2)
    C(k) = loops_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_21,2)
    C(k) = controls_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_22,2)
    C(k) = loops_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_22,2)
    C(k) = controls_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end


max_all = max(max1);
min_all = min(min1);
%boxplot(C,grp,'labels',{'loop distances','control distances'},'symbol','');
%boxplot(C,grouping,'labels',{'loop distances','control distances'},'symbol','')
figure('units','normalized','outerposition',[0 0 1 0.6]);
positions = [1 1.25 2 2.25 3 3.25];
boxplot(C,grouping,'symbol','');
ylabel('Density (Mb/\mum^3)');
%set(gca,'xtick',positions);%[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6))])
set(gca,'xticklabel',{'Chr20 A','Chr20 B','Chr21 A','Chr21 B','Chr22 A','Chr22 B'})
H = sigstar({{'Chr20 A','Chr20 B'},{'Chr21 A','Chr21 B'},{'Chr22 A','Chr22 B'}},[0.01,0.01,0.01]);
% yt = get(gca, 'YTick');
% axis([xlim    0  ceil(max(yt)*1.2)])
% xt = get(gca, 'xtick');
% hold on
% plot(xt([1]), max(yt)*1.15, '*k')
% hold off
color = ['c', 'y', 'c', 'y','c', 'y'];
h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
end

c = get(gca, 'Children');

hleg1 = legend(c(1:2), 'Compartment A density', 'Compartment B density');
ylim([0 max_all]);
set(H,'color','r')
%close
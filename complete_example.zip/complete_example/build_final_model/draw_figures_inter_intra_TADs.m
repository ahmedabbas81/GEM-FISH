% Density_A is a column vector
clear all
dir_name = 'common_figures_final_en_shaa_Allah';
mkdir(dir_name);
filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_20_outputs/using_square_difference/inter_intra_comp_distances.mat';
load(filename)

loops_20 = inter_comp';
controls_20 = intra_comp';
max1(1) = max(quantile(loops_20,0.8)*2,quantile(controls_20,0.8)*2);
min1(1) = min(min(loops_20),min(controls_20));
clear inter_comp intra_comp

filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_21_outputs/using_square_difference/inter_intra_comp_distances.mat';
load(filename)

loops_21 = inter_comp';
controls_21 = intra_comp';
max1(1) = max(quantile(loops_21,0.8)*2,quantile(controls_21,0.8)*2);
min1(1) = min(min(loops_21),min(controls_21));
clear inter_comp intra_comp

filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_22_outputs/using_square_difference/inter_intra_comp_distances.mat';
load(filename)

loops_22 = inter_comp';
controls_22 = intra_comp';
max1(1) = max(quantile(loops_22,0.8)*2,quantile(controls_22,0.8)*2);
min1(1) = min(min(loops_22),min(controls_22));
clear inter_comp intra_comp


filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xa_outputs/using_square_difference/inter_intra_comp_distances.mat';
load(filename)

loops_Xa = inter_comp';
controls_Xa = intra_comp';
max1(1) = max(quantile(loops_Xa,0.8)*2,quantile(controls_Xa,0.8)*2);
min1(1) = min(min(loops_Xa),min(controls_Xa));
clear inter_comp intra_comp

filename = '/home/Ahmed/gem-master-local/Nov-22-night/chr_Xi_outputs/using_square_difference/inter_intra_comp_distances.mat';
load(filename)

loops_Xi = inter_comp';
controls_Xi = intra_comp';
max1(1) = max(quantile(loops_Xi,0.8)*2,quantile(controls_Xi,0.8)*2);
min1(1) = min(min(loops_Xi),min(controls_Xi));
clear inter_comp intra_comp

k = 1;
grp = 0;
for i = 1 : size(loops_20,2)
    C(k) = loops_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_20,2)
    C(k) = controls_20(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_21,2)
    C(k) = loops_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_21,2)
    C(k) = controls_21(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_22,2)
    C(k) = loops_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_22,2)
    C(k) = controls_22(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_Xa,2)
    C(k) = loops_Xa(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_Xa,2)
    C(k) = controls_Xa(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(loops_Xi,2)
    C(k) = loops_Xi(1,i);
    grouping(k) = grp;
    k = k + 1;
end
grp = grp + 1;
for i = 1 : size(controls_Xi,2)
    C(k) = controls_Xi(1,i);
    grouping(k) = grp;
    k = k + 1;
end

max_all = max(max1);
min_all = min(min1);
%boxplot(C,grp,'labels',{'loop distances','control distances'},'symbol','');
%boxplot(C,grouping,'labels',{'loop distances','control distances'},'symbol','')
figure('units','normalized','outerposition',[0 0 1 0.6]);
positions = [1 1.25 2 2.25 3 3.25 4 4.25 5 5.25];
boxplot(C,grouping,'positions',positions,'symbol','');
ylabel('Distance (nm)');
set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6)) mean(positions(7:8)) mean(positions(9:10))])
set(gca,'xticklabel',{'Chr20','Chr21','Chr22','ChrXa','ChrXi'})
%H = sigstar({{'Chr20 A','Chr20 B'},{'Chr21 A','Chr21 B'},{'Chr22 A','Chr22 B'}},[0.01,0.01,0.01]);
% yt = get(gca, 'YTick');
% axis([xlim    0  ceil(max(yt)*1.2)])
% xt = get(gca, 'xtick');
% hold on
% plot(xt([1]), max(yt)*1.15, '*k')
% hold off
color = ['c', 'y', 'c', 'y','c', 'y', 'c', 'y','c', 'y'];
h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
end

c = get(gca, 'Children');

hleg1 = legend(c(1:2), 'Inter-compartment pairwise distances', 'Intra-compartment pairwise distances');
%legend('Inter-compartment pairwise distances', 'Intra-compartment pairwise distances');
ylim([0 max_all]);
title('A')
filename = sprintf('%s/inter_and_intra_comp_distances.fig',dir_name);
saveas(gcf,filename);

%set(H,'color','r')
close
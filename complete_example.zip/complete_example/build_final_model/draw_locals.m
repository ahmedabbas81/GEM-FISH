chr_num_string = '21';
mkdir('chr21_locals');
hic_fish_structure = sprintf('/home/Ahmed/GEM-master-fish-Nov4/chr_%s_square_diff/conformation1.txt',chr_num_string);

str = load(hic_fish_structure);
figure,
plot3(str(:,1),str(:,2),str(:,3),'o- m');
xlim([-2000 1000])
    ylim([-2000 2000])
    zlim([-1500 1500])
filename = sprintf('chr21_locals/global.png');
saveas(gcf,filename);
close

for i = 1 : 34
    local_structures_path=sprintf('/home/Ahmed/gem-master-local-backup/chr%s_local_structures_Rao_5kb',chr_num_string);
    fname = sprintf('%s/tad%d/conformation1.txt',local_structures_path,i);
    structure = load(fname);
    figure,
    plot3(structure(:,1),structure(:,2),structure(:,3),'x- c');
    xlim([-1500 1000])
    ylim([-1500 1000])
    zlim([-1500 1000])
    filename = sprintf('chr21_locals/tad%d.png',i);
    saveas(gcf,filename);
    close
end


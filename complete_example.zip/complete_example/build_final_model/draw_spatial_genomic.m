function draw_spatial_genomic(chr_num_string,chr_num,folder_name, nTADs)

%mkdir(folder_name);

tads_positions_path=sprintf('/home/Ahmed/read_dixon_data_program/chr%d_outputs/tad_positions.txt',chr_num);

fish_distances_file = sprintf('/home/Ahmed/Clean_Version/chr_%s_data/fish_distances_chr%s.csv',chr_num_string,chr_num_string);

hic_structure_path = sprintf('/home/Ahmed/GEM-master/Dixon_FISH_Only_40_chr%s/conformation1.txt',chr_num_string);
hic_structure = load(hic_structure_path);
hic_fish_structure_path = sprintf('/home/Ahmed/GEM-master-fish-Nov4/chr_%s/conformation1.txt',chr_num_string);
hic_fish_structure = load(hic_fish_structure_path);
distances_hic_fish = squareform(pdist(hic_fish_structure(:,:)));
distances_hic = squareform(pdist(hic_structure(:,:)));
distances_fish = csvread(fish_distances_file);
tad_positions = load(tads_positions_path);
k1 = 1;
for i = 1 : nTADs
    i1 = i;
    startI = tad_positions(i1,1);
    endI = tad_positions(i1,2);
    midI = (startI+endI)/2;
    for j1 = 1 : nTADs
        j2 = j1;
        sj = tad_positions(j2,1);
        ej = tad_positions(j2,2);
        mid = (sj+ej)/2;
        g_dist = abs(mid - midI);
        if(distances_fish(i1,j2) ~= 0 && g_dist ~= 0)
            spatial_distances_hic_fish(k1,1) = distances_hic_fish(i1,j2)/1000.0;
            s_hic_fish(k1,1) = log10(distances_hic_fish(i1,j2)/1000.0);
            spatial_distances_hic(k1,1) = distances_hic(i1,j2)/1000.0;
            s_hic(k1,1) = log10(distances_hic(i1,j2)/1000.0);
            spatial_distances_fish(k1,1) = distances_fish(i1,j2);
            s_fish(k1,1) = log10(distances_fish(i1,j2));
            genomic_distances(k1,1) = g_dist;
            g(k1,1) = log10(g_dist);
            k1 = k1 + 1;
        end
    end
end
[fun_fish,gof] = fit((genomic_distances),(spatial_distances_fish),'power1');
[fun_fish_hic,gof] = fit((genomic_distances),(spatial_distances_hic_fish),'power1');
[fun_hic,gof] = fit((genomic_distances),(spatial_distances_hic),'power1');
%P=polyfitZero(log10(genomic_distances),log10(spatial_distances),1);
%return;
% fitvalues=coeffvalues(fun);
%if(flag_plotting)
%     figure,
%     filename = sprintf('./%s/gen_spatial_relation.png',out_dir_name);
%     plot(fun,log10(genomic_distances),log10(spatial_distances));

fitvalues_fish = coeffvalues(fun_fish)
fitvalues_hic_fish = coeffvalues(fun_fish_hic)
fitvalues_hic = coeffvalues(fun_hic);

for i = 1 : size(genomic_distances,1)
    fit_fish(i) = fitvalues_fish(1)*genomic_distances(i)^fitvalues_fish(2);
    fit_fish_hic(i) = fitvalues_hic_fish(1)*genomic_distances(i)^fitvalues_hic_fish(2);
    fit_hic(i) = fitvalues_hic(1)*genomic_distances(i)^fitvalues_hic(2);
end

% figure,
% plot(genomic_distances(:),fit_fish(:),'b');
% hold on
% plot(genomic_distances(:),fit_fish_hic(:),'c');
% hold on
% plot(genomic_distances(:),fit_hic(:),'m');
% hold off
% legend('Experimental FISH','GEM-FISH','GEM')
% figure,
% plot(fun_fish,'b','LineWidth',2);%,genomic_distances(:),spatial_distances_fish(:),'g');
% hold on
% plot(fun_fish_hic,'c','LineWidth',2);%genomic_distances(:),spatial_distances_hic_fish(:),'b');
% hold on
% plot(fun_hic,'m','LineWidth',2);%,genomic_distances(:),spatial_distances_hic(:),'r');
% hold off
% xlim([0 max(genomic_distances(:))]);
% xlabel('Genomic distance','FontSize',20);
% ylabel('Spatial distance','FontSize',20);
% legend('Experimental FISH','GEM-FISH','GEM','FontSize',20)
% % plot(genomic_distances(:),fun_fish_hic,'- b');
% % hold on
% % plot(genomic_distances(:),fun_hic,'- r');
% % hold off
% 
% filename = sprintf('%s/spatial_genomic_%s.png',folder_name,chr_num_string);
% saveas(gcf,filename);
% [fun_fish_log,gof] = fit((g),(s_fish),'poly1');
% fitvalues_fish = coeffvalues(fun_fish_log);
% p_hic_fish = polyfix(g,s_hic_fish,1,0,fitvalues_fish(2)); 
% p_hic = polyfix(g,s_hic,1,0,fitvalues_fish(2)); 
% % [fun_fish_hic_log,gof] = fit((g),(s_hic_fish),'poly1');
% % [fun_hic_log,gof] = fit((g),(s_hic),'poly1');
% % fitvalues_fish = coeffvalues(fun_fish_log);
% % fitvalues_hic_fish = coeffvalues(fun_fish_hic_log);
% % fitvalues_hic = coeffvalues(fun_hic_log);
% filename = sprintf('%s/spatial_genomic_%s_coef.txt',folder_name,chr_num_string);
% fid = fopen(filename,'w');
% fprintf(fid,'fish: %.2f, %.2f\n',fitvalues_fish(1),fitvalues_fish(2));
% % fprintf(fid,'hic_fish: %.2f, %.2f\n',fitvalues_hic_fish(1),fitvalues_hic_fish(2));
% % fprintf(fid,'hic: %.2f, %.2f\n',fitvalues_hic(1),fitvalues_hic(2));
% 
% fprintf(fid,'hic_fish: %.2f, %.2f\n',p_hic_fish(1),p_hic_fish(2));
% fprintf(fid,'hic: %.2f, %.2f\n',p_hic(1),p_hic(2));
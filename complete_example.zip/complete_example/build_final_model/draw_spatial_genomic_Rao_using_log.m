function [p,p2,p3] = draw_spatial_genomic_Rao(chr_num_string,chr_num,folder_name, nTADs,ticks,ticklabels)

%mkdir(folder_name);

%tads_positions_path=sprintf('/home/ahmed/read_dixon_data_program/chr%d_outputs/tad_positions.txt',chr_num);
tads_positions_path=sprintf('/home/ahmed/Rao_data/tads_chr%s_hg19.txt',chr_num_string);
fish_distances_file = sprintf('/home/ahmed/Clean_Version/chr_%s_data/fish_distances_chr%s.csv',chr_num_string,chr_num_string);

hic_structure_path = sprintf('/home/ahmed/GEM-master-2/Rao_FISH_Only_5_chr%s/conformation1.txt',chr_num_string);
hic_structure = load(hic_structure_path);
hic_fish_structure_path = sprintf('/home/ahmed/GEM-master-fish-Nov4/chr_%s_square_diff/conformation1.txt',chr_num_string);
hic_fish_structure = load(hic_fish_structure_path);
distances_hic_fish = squareform(pdist(hic_fish_structure(:,:)));
distances_hic_fish = distances_hic_fish/1000;
distances_hic = squareform(pdist(hic_structure(:,:)));
distances_hic = distances_hic/1000;
distances_fish = csvread(fish_distances_file);
tad_positions = load(tads_positions_path);
k1 = 1;
for i = 1 : nTADs
    i1 = i;
    startI = tad_positions(i1,1);
    endI = tad_positions(i1,2);
    midI = (startI+endI)/2;
    for j1 = 1 : nTADs
        j2 = j1;
        sj = tad_positions(j2,1);
        ej = tad_positions(j2,2);
        mid = (sj+ej)/2;
        g_dist = abs(mid - midI);
        if(distances_fish(i1,j2) ~= 0 && g_dist ~=0)
            spatial_distances_hic_fish(k1,1) = distances_hic_fish(i1,j2);
            s_hic_fish(k1,1) = log10(distances_hic_fish(i1,j2));
            spatial_distances_hic(k1,1) = distances_hic(i1,j2);
            s_hic(k1,1) = log10(distances_hic(i1,j2));
            spatial_distances_fish(k1,1) = distances_fish(i1,j2);
            s_fish(k1,1) = log10(distances_fish(i1,j2));
            genomic_distances(k1,1) = g_dist;
            g(k1,1) = log10(g_dist);
            k1 = k1 + 1;
        end
    end
end
p = polyfit(g,s_fish,1);

p2 = polyfit(g,s_hic_fish,1);

p3 = polyfit(g,s_hic,1);


 
h = plot(fun_hic,genomic_distances,spatial_distances_hic);%,'Linewidth',2);
fitvalues=coeffvalues(fun_hic);
text_legend = sprintf('S = %.2e x G^{%.2f}',fitvalues(1),fitvalues(2)); 
set(gca,'FontSize',16)
t1 = title(t);
set(t1,'FontSize',16)
ax = gca;
ax.XTick = ticks;
ax.XTickLabel = ticklabels
xlabel('Genomic distance "G" (Mbp)')
ylabel('Spatial distance "S" (\mum)')
legend(h,'data',text_legend,'FontSize',16);
fname = sprintf('%s/chr%s_GEM.png',folder_name,chr_num_string);
saveas(gcf,fname);



%ylim([0 max_y+0.5])
[fun_fish,gof] = fit((genomic_distances),(spatial_distances_fish),'power1')
figure,
a = 10^p(2);
b = p(1);
fitvalues=coeffvalues(fun_fish);
text_legend = sprintf('S = %.2e x G^{%.2f}',fitvalues(1),fitvalues(2)); 
h = plot(fun_fish,genomic_distances,spatial_distances_fish);%,'Linewidth',2);
t = sprintf('Chr%s Exp. FISH',chr_num_string);
text_legend = sprintf('S = %.2e x G^{%.2f}',a,b);
title(t);
xlabel('genomic distance (Mbp)')
ylabel('spatial distance (\mum)')
ax = gca;
ax.XTick = ticks;
ax.XTickLabel = ticklabels;
set(gca,'FontSize',16)
t1 = title(t);
set(t1,'FontSize',16)
legend(h,'data',text_legend,'FontSize',16);
fname = sprintf('%s/chr%s_Exp.png',folder_name,chr_num_string);
saveas(gcf,fname);
%ylim([0 max_y+0.5])
[fun_fish_hic,gof] = fit((genomic_distances),(spatial_distances_hic_fish),'power1')
figure,
a = 10^p2(2);
b = p2(1);
% figure,
% for i = 1 : length(genomic_distances)
%     g1(i) = genomic_distances(i);
%     s1(i) = a*g1(i)^b;
% %     plot(g1(i),s1(i),'-r');
% %     hold on
% end
% [g1, I] = sort(g1);
% s1 = s1(I);
% figure
% plot(g1,s1,'-r');
% text_legend = sprintf('S = %.2e x G^{%.2f}',a,b);
fitvalues=coeffvalues(fun_fish_hic);
text_legend = sprintf('S = %.2e x G^{%.2f}',fitvalues(1),fitvalues(2)); 
h = plot(fun_fish_hic,genomic_distances,spatial_distances_hic_fish);%,'Linewidth',2);
t = sprintf('Chr%s GEM-FISH',chr_num_string);
title(t)
xlabel('genomic distance (Mbp)')
ylabel('spatial distance (\mum)')
ax = gca;
ax.XTick = ticks;
ax.XTickLabel = ticklabels
set(gca,'FontSize',16)
t1 = title(t);
set(t1,'FontSize',16)
legend(h,'data',text_legend,'FontSize',16);
fname = sprintf('%s/chr%s_GEM_FISH.png',folder_name,chr_num_string);
saveas(gcf,fname);
% % % % % fitvalues=coeffvalues(fun);
% % % % %if(flag_plotting)
% % % % %     figure,
% % % % %     filename = sprintf('./%s/gen_spatial_relation.png',out_dir_name);
% % % % %     plot(fun,log10(genomic_distances),log10(spatial_distances));
% % % % 
% fit_fish = coeffvalues(fun_fish)
% fit_hicfish = coeffvalues(fun_fish_hic)
% fit_hic = coeffvalues(fun_hic);
% % % % % 
% % % % % for i = 1 : size(genomic_distances,1)
% % % % %     fit_fish(i) = fitvalues_fish(1)*genomic_distances(i)^fitvalues_fish(2);
% % % % %     fit_fish_hic(i) = fitvalues_hic_fish(1)*genomic_distances(i)^fitvalues_hic_fish(2);
% % % % %     fit_hic(i) = fitvalues_hic(1)*genomic_distances(i)^fitvalues_hic(2);
% % % % % end
% % % % % 
% % % % % % figure,
% % % % % % plot(genomic_distances(:),fit_fish(:),'b');
% % % % % % hold on
% % % % % % plot(genomic_distances(:),fit_fish_hic(:),'c');
% % % % % % hold on
% % % % % % plot(genomic_distances(:),fit_hic(:),'m');
% % % % % % hold off
% % % % % % legend('Experimental FISH','GEM-FISH','GEM')
% % % % % figure,
% % % % % plot(fun_fish,genomic_distances(:),spatial_distances_fish(:),'g');
% % % % % hold on
% % % % % plot(fun_fish_hic,genomic_distances(:),spatial_distances_hic_fish(:),'b');
% % % % % hold on
% % % % % plot(fun_hic,genomic_distances(:),spatial_distances_hic(:),'r');
% % % % % hold off
% % % % % xlim([0 max(genomic_distances(:))]);
% % % % % xlabel('Genomic distance','FontSize',20);
% % % % % ylabel('Spatial distance','FontSize',20);
% % % % % legend('Experimental FISH','GEM-FISH','GEM','FontSize',20)
% % % % % % plot(genomic_distances(:),fun_fish_hic,'- b');
% % % % % % hold on
% % % % % % plot(genomic_distances(:),fun_hic,'- r');
% % % % % % hold off
% % % % % 
% % % % % filename = sprintf('%s/spatial_genomic_%s.png',folder_name,chr_num_string);
% % % % % saveas(gcf,filename);
% % [fun_fish_log,gof] = fit((g),(s_fish),'poly1');
% % fitvalues_fish = coeffvalues(fun_fish_log);
% % p_hic_fish = polyfix(g,s_hic_fish,1,0,fitvalues_fish(2)); 
% % p_hic = polyfix(g,s_hic,1,0,fitvalues_fish(2)); 
% % [fun_fish_hic_log,gof] = fit((g),(s_hic_fish),'poly1');
% % [fun_hic_log,gof] = fit((g),(s_hic),'poly1');
% % fitvalues_fish = coeffvalues(fun_fish_log);
% % fitvalues_hic_fish = coeffvalues(fun_fish_hic_log);
% % fitvalues_hic = coeffvalues(fun_hic_log);
% 
% g1 = [0 : 1E4 : max(genomic_distances)];
% fish = fit_fish(1)*g1.^fit_fish(2);
% hic_fish = fit_hicfish(1)*g1.^fit_hicfish(2);
% hic = fit_hic(1)*g1.^fit_hic(2);
% figure,
% plot(g1/(10^6),fish/1000,'-k','LineWidth',2);
% hold on
% plot(g1/(10^6),hic_fish/1000,'-c','LineWidth',2);
% hold on
% plot(g1/(10^6),hic/1000,'-m','LineWidth',2);
% xlabel('genomic distance (Mbp)','FontSize',18)
% ylabel('spatial distance (\mum)','FontSize',18)
% xlim([0 max(g1/(10^6))+0.1*max(g1/(10^6))])
% hleg1 = legend('Exp. FISH','GEM-FISH','GEM','Location','northwest')
% set(hleg1, 'FontSize', 16)
% xt = get(gca, 'XTick');
% set(gca, 'FontSize', 16);
% xt = get(gca, 'YTick');
% set(gca, 'FontSize', 16)
% filename = sprintf('%s/spatial_genomic_%s_coef.png',folder_name,chr_num_string);
% saveas(gcf,filename);
% %fid = fopen(filename,'w');
% % fprintf(fid,'fish: %.2f, %.2f\n',fitvalues_fish(1),fitvalues_fish(2));
% % % fprintf(fid,'hic_fish: %.2f, %.2f\n',fitvalues_hic_fish(1),fitvalues_hic_fish(2));
% % % fprintf(fid,'hic: %.2f, %.2f\n',fitvalues_hic(1),fitvalues_hic(2));
% % 
% % fprintf(fid,'hic_fish: %.2f, %.2f\n',p_hic_fish(1),p_hic_fish(2));
% % fprintf(fid,'hic: %.2f, %.2f\n',p_hic(1),p_hic(2));
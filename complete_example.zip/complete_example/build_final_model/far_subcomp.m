clear all
chr_num = 21;
file_loci = '/home/Ahmed/Rao/Rao_data/Rao_files_21_5kb/loci_tad_1_Rao_5kb.txt';
loci = load(file_loci);
path = sprintf('/home/Ahmed/gem-master-local-backup/Dec6_Rao/chr_%d_outputs/using_square_difference/structures_and_stats.mat',chr_num);
load('/home/Ahmed/gem-master-local-backup/Dec6_Rao/chr_21_outputs/using_square_difference/structures_and_stats.mat');
tads_positions_path=sprintf('/home/Ahmed/Rao/Rao_data/tads_chr%d_hg19.txt',chr_num);

blocks_file = sprintf('/home/Ahmed/gem-master-local-backup/Dec6_Rao/chr_%d_outputs/using_square_difference/blocks.mat',chr_num);
%load(blocks_file);
blocks = [67	577	425	553	385	273	169	193	265	65	321	113	129	65	145	73	97	49	305	41	153	89	153	209	337	147	145	57	187	65	137	73	145	157];
tad_center = 2;

% start_point = 0;
% for i = 1 : tad_center - 1
%     start_point = start_point + blocks(i);
% end
% p_center = start_point + 150;%B2 point
% tad_intra = 2;
% start_point = 0;
% for i = 1 : tad_center - 1
%     start_point = start_point + blocks(i);
% end
% p_intra = [];
% for i = 1 : 10
%     p_intra = [p_intra;start_point+i];
% end
% 
% 
% tad_inter = 2;
% start_point = 0;
% for i = 1 : tad_inter - 1
%     start_point = start_point + blocks(i);
% end
% p_inter = [];
% for i = 1 : 10
%     p_inter = [p_inter;start_point+255+i];
% end


start_point = 0;
for i = 1 : tad_center - 1
    start_point = start_point + blocks(i);
end
p_center = start_point + 150;%B2 point
locus_center = 150;
tad_intra = 2;
start_point = 0;
for i = 1 : tad_intra - 1
    start_point = start_point + blocks(i);
end
p_intra = [];
loci_intra = [];
for i = 1 : 10
    p_intra = [p_intra;start_point+7+i];
    loci_intra = [loci_intra;7+i];
end


tad_inter = 2;
start_point = 0;
for i = 1 : tad_inter - 1
    start_point = start_point + blocks(i);
end
p_inter = [];
loci_inter = [];
for i = 1 : 10
    p_inter = [p_inter;start_point+256+i];
    loci_inter = [loci_inter;256+i];
end


% p_inter = [];
% for i = 1 : 11
%     p_inter = [p_inter;p_center2 - i];
% end
% p_intra = [];
% for i = 30 : 40
%     p_intra = [p_intra;p_center2 + i];
% end
% 
% 
% center = 20;
% diff = 15;
% intra = [];
% inter = [];
for i = 1 : size(p_inter,1)
    p_l2 = high_resolution_structure(p_inter(i),:);
    p_l1 = high_resolution_structure(p_center,:);
    p_l3 = high_resolution_structure(p_intra(i),:);

    inter(i) = norm(p_l1 - p_l2);
    intra(i) = norm(p_l1 - p_l3);
end
inter_median = median(inter)
intra_median = median(intra)
t(1,:) = intra(:);
t(2,:) = inter(:);
p = ranksum(inter,intra)

file_out = fopen('chr21_positions_tad2_Dec27_new.txt','w');
fprintf(file_out,'L1 (sub-comp B2) at position: chr21:%d-%d\n',loci(locus_center),loci(locus_center)+5000);
fprintf(file_out,'L2 (sub-comp B2) at position: chr21:%d-%d\n',loci(min(loci_intra)),loci(max(loci_intra)));
fprintf(file_out,'L3 (sub-comp B1) at position: chr21:%d-%d\n',loci(min(loci_inter)),loci(max(loci_inter)));
fprintf(file_out,'The genomic distance between L1 and L2 ~ %d\n',abs(loci(locus_center) - loci(round(mean(loci_intra)))));
fprintf(file_out,'The genomic distance between L1 and L3 ~ %d\n',abs(loci(locus_center) - loci(round(mean(loci_inter)))));
fprintf(file_out,'The spatial distance between L1 and L2 is expected to be smaller tha the spatial distance between L1 and L3');


% p_inter = [];
% for i = 1 : 11
%     p_inter = [p_inter;p_center2 - i];
% end
% p_intra = [];
% for i = 30 : 40
%     p_intra = [p_intra;p_center2 + i];
% end
% 
% 
% center = 20;
% diff = 15;
% intra = [];
% inter = [];
for i = 1 : size(p_inter,1)
    p_l2 = high_resolution_structure(p_inter(i),:);
    p_l1 = high_resolution_structure(p_center,:);
    p_l3 = high_resolution_structure(p_intra(i),:);

    inter(i) = norm(p_l1 - p_l2);
    intra(i) = norm(p_l1 - p_l3);
end
inter_median = median(inter)
intra_median = median(intra)
t(1,:) = intra(:);
t(2,:) = inter(:);
p = ranksum(inter,intra)

file_out = fopen('chr21_positions_tad2_Dec27.txt','w');
fprintf(file_out,'L1 (sub-comp B2) at position: chr21:%d-%d\n',loci(p_center),loci(p_center)+5000);
fprintf(file_out,'L2 (sub-comp B2) at position: chr21:%d-%d\n',loci(min(p_intra)),loci(max(p_intra)));
fprintf(file_out,'L3 (sub-comp B1) at position: chr21:%d-%d\n',loci(min(p_inter)),loci(max(p_inter)));
fprintf(file_out,'The genomic distance between L1 and L2 ~ %d\n',abs(loci(p_center) - loci(max(p_intra))));
fprintf(file_out,'The genomic distance between L1 and L3 ~ %d\n',abs(loci(p_center) - loci(min(p_inter))));
fprintf(file_out,'The spatial distance between L1 and L2 is expected to be smaller tha the spatial distance between L1 and L3');

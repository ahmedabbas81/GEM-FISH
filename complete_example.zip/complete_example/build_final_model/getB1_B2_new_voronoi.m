function [high_resolution_structure,comp,size_b1,size_b2,positions,reduced_positions,scores_b1,scores_b2,scores_A1] = getB1_B2_new_voronoi(H3K27me3_file,H3K36me3_file,H3K27ac_file,H3K79me2_file,H3K4me1_file,first_tad,last_tad,tads_p,chr_num,dir_name,B_tads)
A = H3K27me3_file;
%histogram(A,20);
k = 1;
for i = 1 : size(A,1)
    if(A(i,3)>0)
        B(k,1:3) = A(i,:);
        k = k + 1;
    end
end
%B = A(A(:,3)>0);
[C,I] = sortrows(B,-3); 
stop_index = round(size(C,1)/20);
for i = 1 : stop_index
    C(i,4) = 20;
end
k = 1;
range = C(stop_index+1,3) - min(C(:,3));
m = min(C(:,3));
l = size(C,1);
for k = 1 : 19
    for i = stop_index+1 : size(C,1)
        value = C(i,3)-m;
        upper = range*k/19;
        lower = range*(k-1)/19;
        if(value <= upper && value>=lower)
            C(i,4) = k;
        end
    end
end
H3K27me3 = sortrows(C,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = H3K27ac_file;
%histogram(A,20);
k = 1;
for i = 1 : size(A,1)
    if(A(i,3)>0)
        B(k,1:3) = A(i,:);
        k = k + 1;
    end
end
%B = A(A(:,3)>0);
[C,I] = sortrows(B,-3); 
stop_index = round(size(C,1)/20);
for i = 1 : stop_index
    C(i,4) = 20;
end
k = 1;
range = C(stop_index+1,3) - min(C(:,3));
m = min(C(:,3));
l = size(C,1);
for k = 1 : 19
    for i = stop_index+1 : size(C,1)
        value = C(i,3)-m;
        upper = range*k/19;
        lower = range*(k-1)/19;
        if(value <= upper && value>=lower)
            C(i,4) = k;
        end
    end
end
H3K27ac = sortrows(C,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A = H3K79me2_file;
%histogram(A,20);
k = 1;
for i = 1 : size(A,1)
    if(A(i,3)>0)
        B(k,1:3) = A(i,:);
        k = k + 1;
    end
end
%B = A(A(:,3)>0);
[C,I] = sortrows(B,-3); 
stop_index = round(size(C,1)/20);
for i = 1 : stop_index
    C(i,4) = 20;
end
k = 1;
range = C(stop_index+1,3) - min(C(:,3));
m = min(C(:,3));
l = size(C,1);
for k = 1 : 19
    for i = stop_index+1 : size(C,1)
        value = C(i,3)-m;
        upper = range*k/19;
        lower = range*(k-1)/19;
        if(value <= upper && value>=lower)
            C(i,4) = k;
        end
    end
end
H3K79me2 = sortrows(C,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A = H3K4me1_file;
%histogram(A,20);
k = 1;
for i = 1 : size(A,1)
    if(A(i,3)>0)
        B(k,1:3) = A(i,:);
        k = k + 1;
    end
end
%B = A(A(:,3)>0);
[C,I] = sortrows(B,-3); 
stop_index = round(size(C,1)/20);
for i = 1 : stop_index
    C(i,4) = 20;
end
k = 1;
range = C(stop_index+1,3) - min(C(:,3));
m = min(C(:,3));
l = size(C,1);
for k = 1 : 19
    for i = stop_index+1 : size(C,1)
        value = C(i,3)-m;
        upper = range*k/19;
        lower = range*(k-1)/19;
        if(value <= upper && value>=lower)
            C(i,4) = k;
        end
    end
end
H3K4me1 = sortrows(C,1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A = H3K36me3_file;

k = 1;
for i = 1 : size(A,1)
    if(A(i,3)>0)
        B(k,1:3) = A(i,:);
        k = k + 1;
    end
end

[C,I] = sortrows(B,-3); 
stop_index = round(size(C,1)/20);
for i = 1 : stop_index
    C(i,4) = 20;
end
k = 1;
range = C(stop_index+1,3) - min(C(:,3));
m = min(C(:,3));
l = size(C,1);
for k = 1 : 19
    for i = stop_index+1 : size(C,1)
        value = C(i,3)-m;
        upper = range*k/19;
        lower = range*(k-1)/19;
        if(value <= upper && value>=lower)
            C(i,4) = k;
        end
    end
end
H3K36me3 = sortrows(C,1);

% csvwrite('H3K36me3_IMR90_50kb.csv',H3K36me3);
% 
% clear all
clear A B
A = H3K36me3;
B = H3K27me3;
C = H3K27ac;
D = H3K79me2;
E = H3K4me1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

path_enr = sprintf('/home/ahmed/epigenetic_data/all_enr_chr%d_50k_with_original_data.txt',chr_num);
enr_matrix = load(path_enr);
for i = 1 : size(A,1)
    flag = 0;
    for j = 1 : size(B,1)
        if(A(i,1) == B(j,1) && A(i,1)>=tads_p(first_tad,1) && A(i,1)<tads_p(last_tad,2))
            A(i,5) = B(j,3);
            A(i,6) = B(j,4);
            flag = 1;
            break;
        end
    end
    if(flag == 0)
        A(i,5) = 0;
        A(i,6) = 0;
    end
           
end
for i = 1 : size(A,1)
    flag = 0;
    for j = 1 : size(C,1)
        if(A(i,1) == C(j,1) && A(i,1)>=tads_p(first_tad,1) && A(i,1)<tads_p(last_tad,2))
            A(i,7) = C(j,3);
            A(i,8) = C(j,4);
            flag = 1;
            break;
        end
    end
    if(flag == 0)
        A(i,7) = 0;
        A(i,8) = 0;
    end
           
end

for i = 1 : size(A,1)
    flag = 0;
    for j = 1 : size(D,1)
        if(A(i,1) == D(j,1) && A(i,1)>=tads_p(first_tad,1) && A(i,1)<tads_p(last_tad,2))
            A(i,9) = D(j,3);
            A(i,10) = D(j,4);
            flag = 1;
            break;
        end
    end
    if(flag == 0)
        A(i,9) = 0;
        A(i,10) = 0;
    end
           
end

for i = 1 : size(A,1)
    flag = 0;
    for j = 1 : size(E,1)
        if(A(i,1) == E(j,1) && A(i,1)>=tads_p(first_tad,1) && A(i,1)<tads_p(last_tad,2))
            A(i,11) = E(j,3);
            A(i,12) = E(j,4);
            flag = 1;
            break;
        end
    end
    if(flag == 0)
        A(i,11) = 0;
        A(i,12) = 0;
    end
           
end
A = A(A(:,5)>0,:);
A27 = A(A(:,6)>15,:);
A36 = A(A(:,4)>15,:);
figure,
plot(A(:,6),A(:,4),'x');
close
k = 1;
for i = 1 : size(A,1)
    if(A(i,4) < 3 && A(i,4)>0 && A(i,6) >= 10)
        B1(k,:) = A(i,:);
        for j=1:size(enr_matrix,1)
            if(B1(k,1) == enr_matrix(j,1))
                scores_b1(k,:) = enr_matrix(j,:);
                break;
            end
        end
        k = k + 1;
    end
end
k = 1;
for i = 1 : size(A,1)
    if(A(i,4) < 3 && A(i,4)>0 && A(i,6) < 3 && A(i,6)>=1 && A(i,8) < 3 && A(i,8)>=1 && A(i,10) < 3 && A(i,10)>=1 && A(i,12) < 3 && A(i,12)>=1)
        B2(k,:) = A(i,:);
        for j=1:size(enr_matrix,1)
            if(B2(k,1) == enr_matrix(j,1))
                scores_b2(k,:) = enr_matrix(j,:);
                break;
            end
        end
        k = k + 1;
    end
end
k = 1;
for i = 1 : size(A,1)
    if(A(i,6) < 3 && A(i,6)>0 && (A(i,4) >= 10 && A(i,8)>=10 && A(i,10)>=10 && A(i,12)>=10))
        Acomp1(k,:) = A(i,:);
        for j=1:size(enr_matrix,1)
            if(Acomp1(k,1) == enr_matrix(j,1))
                scores_A1(k,:) = enr_matrix(j,:);
                break;
            end
        end
        k = k + 1;
    end
end
% for i = 1 : size(A,1)
%     if(A(i,4) > 10 && A(i,3)>7)
%         fprintf('%d, %d\n',A(i,1),A(i,2));
%     end
% end
ib1= 1;
ib2 = 1;
tads_file = sprintf('/home/ahmed/Rao_data/tads_chr%d_hg19.txt',chr_num);
tads = load(tads_file);
k = 1;
for i = 1 : length(B_tads)
    tadnum = B_tads(i);
    tads2(k,:) = tads(tadnum,:);
    k = k + 1;
end
% clear tads
% tads = tads2;
%tadnum = 2;
B1_comp = [];
B1_positions = [];
B2_comp = [];
B2_positions = [];
A_positions = [];
k = 1;
for i = 1 : size(B1,1)
    if(B1(i,1) < tads(1,1))
        continue;
    else
        B1_new(k,:) = B1(i,:);
        k = k + 1;
    end
end
clear B1
B1 = B1_new;


k = 1;
for i = 1 : size(B2,1)
    if(B2(i,1) < tads(1,1))
        continue;
    else
        B2_new(k,:) = B2(i,:);
        k = k + 1;
    end
end
clear B2
B2 = B2_new;

k = 1;
for i = 1 : size(Acomp1,1)
    if(Acomp1(i,1) < tads(1,1))
        continue;
    else
        A_new(k,:) = Acomp1(i,:);
        k = k + 1;
    end
end
clear Acomp1
Acomp1 = A_new;


%    file_loci = sprintf('/home/ahmed/Rao_data/Rao_files_%d_5kb/loci_tad_%d_Rao_5kb.txt',chr_num,tadnum-1);
 %   loci = load(file_loci);
    path = sprintf('/home/ahmed/gem-master-local-backup_lambdaE_11/feb12_Rao%d/chr_%d_outputs/using_square_difference/structures_and_stats.mat',chr_num,chr_num);
    load(path);
    structure = high_resolution_structure;
    [V,C] = voronoin(structure);
    blocks_file = sprintf('/home/ahmed/gem-master-local-backup_lambdaE_11/feb12_Rao%d/chr_%d_outputs/using_square_difference/blocks.mat',chr_num,chr_num);
    load(blocks_file);
%     blocks = [67	577	425	553	385	273	169	193	265	65	321	113	129	65	145	73	97	49	305	41	153	89	153	209	337	147	145	57	187	65	137	73	145	157];
    for b1 = 1 : size(B1,1)
        for j = 1 : size(reduced_positions,1)
            if(reduced_positions(j,1)>=B1(b1,1) && reduced_positions(j,1)<B1(b1,2))
                B1_comp = [B1_comp;[high_resolution_structure(j,1),high_resolution_structure(j,2),high_resolution_structure(j,3)]];
                B1_positions = [B1_positions;[reduced_positions(j,1),reduced_positions(j,2),j]];
                high_resolution_structure(j,5) = -10;
            end
        end
    end
    for b2 = 1 : size(B2,1)
        for j = 1 : size(reduced_positions,1)
            if(reduced_positions(j,1)>=B2(b2,1) && reduced_positions(j,1)<B2(b2,2))
                B2_comp = [B2_comp;[high_resolution_structure(j,1),high_resolution_structure(j,2),high_resolution_structure(j,3)]];
                B2_positions = [B2_positions;[reduced_positions(j,1),reduced_positions(j,2),j]];
                high_resolution_structure(j,5) = 10;
            end
        end
    end
    A_comp = [];
    for b2 = 1 : size(Acomp1,1)
        for j = 1 : size(reduced_positions,1)
            if(reduced_positions(j,1)>=Acomp1(b2,1) && reduced_positions(j,1)<Acomp1(b2,2))
                A_comp = [A_comp;[high_resolution_structure(j,1),high_resolution_structure(j,2),high_resolution_structure(j,3)]];
                A_positions = [A_positions;[reduced_positions(j,1),reduced_positions(j,2),j]];
                high_resolution_structure(j,5) = 100;
            end
        end
    end           



comp = [B1_comp;B2_comp];
positions = [B1_positions;B2_positions];
size_b1 = size(B1_comp,1);
size_b2 = size(B2_comp,1);

function [Rg_sq_left Rg_sq_ours Rg_sq_right] = get_Rg_SE(chr_num_string,tad_number,start_bp,end_bp)
s_path = sprintf('chr%s_local_structures_Rao_5kb/tad%d/conformation1.txt',chr_num_string,tad_number);
loci_file = sprintf('/home/ahmed/Rao_data/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num_string,tad_number-1);
loci = load(loci_file);
structure = load(s_path);
for i = 2 : size(loci,1)
    if(start_bp > loci(i-1,1) && start_bp < loci(i,1))
        start_point = i;
        break;
    end
end
for i = 2 : size(loci,1)
    if(end_bp > loci(i-1,1) && end_bp < loci(i,1))
        end_point = i;
        break;
    end
end
structure_length = end_point - start_point+1;
our_structure = structure(start_point:end_point,:);
left_structure = structure(max(1,start_point-structure_length):start_point-1,:);
right_structure = structure(end_point+1:end_point+structure_length,:);

[Rg_sq_left, center] = calcRg(left_structure);
[Rg_sq_right, center] = calcRg(right_structure);
[Rg_sq_ours, center] = calcRg(our_structure);



function [exp_corr, hic_fish_corr,hic_corr] = get_compartments(original,hic_fish,hic,out_dir_name,file_name,polarization_flag,high_resolution_distances,volumes_ind,GL_ind)
for i = 1 : size(original,1)
    for j = 1 : size(original,2)
        X = original(:,i);
        X1 = exclude_elements(X,i,j);
        X = original(:,j);
        X2 = exclude_elements(X,i,j);
        
        R = corrcoef(X1,X2);
        exp_corr(i,j) = R(1,2);
        clear X1 X2
        X = hic_fish(:,i);
        X1 = exclude_elements(X,i,j);
        X = hic_fish(:,j);
        X2 = exclude_elements(X,i,j);
        R = corrcoef(X1,X2);
        hic_fish_corr(i,j) = R(1,2);
        clear X1 X2
        X = hic(:,i);
        X1 = exclude_elements(X,i,j);
        X = hic(:,j);
        X2 = exclude_elements(X,i,j);
        R = corrcoef(X1,X2);
        hic_corr(i,j) = R(1,2);
        clear X1 X2
    end
end
title1 = 'correlated normalized FISH distances';
R1 = corrcoef(exp_corr,hic_fish_corr);
title2 = sprintf('correlated normalized Hi-C + FISH\nCC = %.2f',R1(1,2));
R1 = corrcoef(exp_corr,hic_corr);
title4 = sprintf('correlated normalized hic\nCC = %.2f',R1(1,2));
dir_name = out_dir_name;
filename = sprintf('%s_correlated_normalized_distances',file_name);
%plot_three_figures_final(exp_corr,hic_fish_corr,hic_corr,dir_name,filename);
plot_two_figures_final(exp_corr,hic_fish_corr,dir_name,filename);
f_name = sprintf('%s/correlated_normalized_distances.mat',dir_name);
save(f_name,'exp_corr','hic_fish_corr','hic_corr')

title1 = 'compartments original by correlation';
title2 = sprintf('compartments hic+fish correlation');
title3 = sprintf('compartments hic+fish high res correlation');
title4 = sprintf('compartments hic correlation');
dir_name = out_dir_name;
filename = sprintf('%s',file_name);
filename_original = sprintf('%s_original_comp_correlation.png',file_name);
plot_compartments_final(exp_corr,hic_fish_corr,hic_corr,dir_name,filename,high_resolution_distances,volumes_ind,GL_ind);
% filename = sprintf('%s_normalized',file_name);
% plot_compartments_final(original,hic_fish,hic,dir_name,filename,high_resolution_distances);
%plot_compartments_final(original,hic_fish,hic,dir_name,file_name,high_resolution_distances,volumes_ind,GL_ind)
function get_high_res_and_test(chr_num,chr_num_string,ntads,a_coef,g_s_exp,resolution,plot_figures,score_flag,date,flag_plotting,hic_exp)
out_dir_name = sprintf('%s/chr_%s_outputs',date,chr_num_string);
mkdir(out_dir_name);
if(score_flag == 1)
    inner_dir1 = sprintf('%s/using_square_difference',out_dir_name);
elseif(score_flag == 2)
    inner_dir1 = sprintf('%s/using_log_square_difference',out_dir_name);
end
mkdir(inner_dir1);
local_structures_path=sprintf('/home/ahmed/gem-master-local/chr%s_local_structures_new1',chr_num_string);
hic_matrix_path = sprintf('Chr_raw_files/uij_chr%d.txt',chr_num);
whole_hic_matrix=load(hic_matrix_path);
tads_positions_path=sprintf('/home/ahmed/read_dixon_data_program/chr%d_outputs/tad_positions.txt',chr_num);
fish_distances_file = sprintf('/home/ahmed/Clean_Version/chr_%s_data/fish_distances_chr%s.csv',chr_num_string,chr_num_string);

fish_distances = csvread(fish_distances_file);
fish_distances = 1000*fish_distances;
hic_structure = sprintf('/home/ahmed/GEM-master/Dixon_FISH_Only_40_chr%s/conformation1.txt',chr_num_string);
if(score_flag == 1)
    hic_fish_structure = sprintf('/home/ahmed/GEM-master-fish-Nov4/chr_%s/conformation1.txt',chr_num_string);
elseif(score_flag == 2)
    hic_fish_structure = sprintf('/home/ahmed/GEM-master-fish/log_square_diff_%s/conformation1.txt',chr_num_string);
end
Xa_flag = 0;
% if(chr_num_string == 'Xa')
%     Xa_flag = 1;
% end
loops_file = sprintf('/home/ahmed/gem-master-local/loops_files_hg18/chr%s_loops_hg18.csv',chr_num_string);
enhancers_file = sprintf('/home/ahmed/gem-master-local/super_enhancers_chr%s.csv',chr_num_string);
[high_resolution_structure,distances_tads,loop_distances,volumes_ind,diameters_ind,GL_ind,blocks] = get_high_resolution_structure(hic_fish_structure,hic_structure,local_structures_path,ntads,whole_hic_matrix,resolution,tads_positions_path,a_coef,g_s_exp,inner_dir1,plot_figures,loops_file,flag_plotting,hic_exp,fish_distances,enhancers_file);
fish_corr = test_high_resolution_structure(inner_dir1, tads_positions_path, ntads, a_coef,g_s_exp, fish_distances_file, hic_structure, hic_fish_structure,distances_tads,Xa_flag,flag_plotting,volumes_ind,diameters_ind,GL_ind);
%test_high_resolution_structure(inner_dir1, tads_positions_path, ntads, a_coef,g_s_exp, fish_distances_file, hic_structure, hic_fish_structure,distances_tads,Xa_flag,flag_plotting);
file_blocks = sprintf('%s/blocks.mat',inner_dir1);
save(file_blocks,'blocks');
plot_structure(high_resolution_structure,blocks,fish_corr,inner_dir1);
l_file = sprintf('%s/loop_distances_classified.csv',inner_dir1);
c_file = sprintf('%s/control_distances.csv',inner_dir1);
get_loops_and_controls(l_file,c_file,inner_dir1);


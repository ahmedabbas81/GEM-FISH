function get_high_res_and_test_Rao(chr_num_string,ntads,a_coef,g_s_exp,resolution,out_dir,hic_exp)
%path to the high resolution  3D models of individual TADs
local_structures_path=sprintf('.././create_individual_TAD_models/chr%s_local_structures_Rao_5kb',chr_num_string);
%path to the high resolution Hi-C map (5 Kbp) of the whole chromosome
hic_matrix_path = sprintf('.././collect_hic_data/chr%s_output_files/hic_loci_level_5kb.txt',chr_num_string);
whole_hic_matrix=load(hic_matrix_path);
%locations of TADs of the chromosome
tads_positions_path=sprintf('.././collect_hic_data/tads_chr%s_hg19.txt',chr_num_string);
%Average FISH distances file
fish_distances_file = sprintf('.././create_TAD_level_model/fish_distances_chr%s.csv',chr_num_string);

fish_distances = csvread(fish_distances_file);
fish_distances = 1000*fish_distances; %to make it in nanometers
%path to the TAD-level resolution 3D model of the chromosome
hic_fish_structure = sprintf('.././create_TAD_level_model/chr_%s_TAD_level_resolution/conformation1.txt',chr_num_string);
[high_resolution_structure] = get_high_resolution_structure(hic_fish_structure,local_structures_path,ntads,whole_hic_matrix,resolution,tads_positions_path,a_coef,g_s_exp,out_dir,hic_exp,fish_distances);%,enhancers_file);
file_out = sprintf('%s/final_model.txt',out_dir);
csvwrite(file_out,high_resolution_structure);
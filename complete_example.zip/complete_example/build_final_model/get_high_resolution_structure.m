function [high_resolution_structure] = get_high_resolution_structure(global_structure_path,local_structures_path,ntads,whole_hic_matrix,resolution,tad_positions_path,a_coef,g_s_exp,dir_name,hic_exp,fish_distances)%,enhancers_file)
global_structure=load(global_structure_path);
[rotmat,cornerpoints,global_volume,surface,diameter_low] = minboundbox(global_structure(:,1), global_structure(:,2), global_structure(:,3),'v',3);
tad_positions = load(tad_positions_path);
[d_prior,reduced_positions]=build_reduced_matrix(whole_hic_matrix,tad_positions,resolution,a_coef,g_s_exp,hic_exp,fish_distances);
clear reduced_positions
all_segments = zeros(ntads, 2000, 3); %assuming that max number of blocks in any tad is 2000
blocks = zeros(1,ntads);%%holds the number of blocks in every tad
k = 1;
for i = 1 : ntads
    folder_name = sprintf('%s/tad%d',local_structures_path,i);
    index = 1;
    filename = sprintf('%s/conformation%d.txt',folder_name,index);
    segment = load(filename);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    center_segment = [mean(segment(:,1)),mean(segment(:,2)),mean(segment(:,3))];
    P_first = segment(1,:);
    d = norm(center_segment - P_first);
    P_first_new = [center_segment(1),center_segment(2),center_segment(3)+d];
    v1 = P_first - center_segment;
    v2 = P_first_new - center_segment;
    s1 = [P_first;center_segment];
    s2 = [P_first_new;center_segment];
    [angle, axis_rotation] = find_angle_axis(v1, v2);
    rotated_segment = rotate_structure(segment,angle,axis_rotation,center_segment);
    all_segments(i,1:size(segment,1),:) = rotated_segment(:,:);
    blocks(i) = size(segment,1);
    starting = tad_positions(i,1);
    for j1 = 1 : blocks(i)
        reduced_positions(k,1) = starting;
        reduced_positions(k,2) = starting+resolution-1;
        starting = starting + resolution;
        k = k + 1;
    end
    clear segment rotated_segment
end
centers = calculate_centers(all_segments, blocks);
all_segments_translated = translate_segments(all_segments, global_structure, centers, blocks);
centers2 = calculate_centers(all_segments_translated, blocks); %%centers2 should be exactly equal to global structure
der_old = zeros(ntads-1,3);
alpha = 0.1;
max_iter=10000;%0;
results_file_name=sprintf('%s/results_building_high_res_structure.txt',dir_name);
k1 = 1;

[high_resolution_structure]=build_structure(centers2,all_segments_translated,blocks,d_prior,max_iter,alpha,ntads,results_file_name);
% for i = 1 : ntads
%     for j = 1 : blocks(i)
%         high_resolution_structure(k1,:) = all_segments_translated(i,j,:); 
%         k1 = k1 + 1;
%     end
% end
[rotmat,cornerpoints,global_volume_high,surface,diameter_high] = minboundbox(high_resolution_structure(:,1), high_resolution_structure(:,2), high_resolution_structure(:,3),'v',3);


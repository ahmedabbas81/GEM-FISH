function [V_int,p_index] = get_intersection_berween_two_hulls(hull_a,hull_b)
[Ka,Va] = convhull(hull_a);        
[Kb,Vb] = convhull(hull_b);  

points_a_in_b = [];
for i = 1 : size(Ka,1)
    P1 = hull_a(Ka(i,1),:);
    P2 = hull_a(Ka(i,2),:);
    P3 = hull_a(Ka(i,3),:);
    edge1 = get_points_of_edge(P1,P2,10);
    points_a_in_b = [points_a_in_b;edge1];
    clear edge1
    edge2 = get_points_of_edge(P1,P3,10);
    points_a_in_b = [points_a_in_b;edge2];
    clear edge2
    edge3 = get_points_of_edge(P2,P3,10);
    points_a_in_b = [points_a_in_b;edge3];
    clear edge3
end
size(points_a_in_b)
points_b_in_a = [];
for i = 1 : size(Kb,1)
    P1 = hull_b(Kb(i,1),:);
    P2 = hull_b(Kb(i,2),:);
    P3 = hull_b(Kb(i,3),:);
    edge1 = get_points_of_edge(P1,P2,10);
    points_b_in_a = [points_b_in_a;edge1];
    clear edge1
    edge2 = get_points_of_edge(P1,P3,10);
    points_b_in_a = [points_b_in_a;edge2];
    clear edge2
    edge3 = get_points_of_edge(P2,P3,10);
    points_b_in_a = [points_b_in_a;edge3];
    clear edge3
end

a_in_b = inhull(points_a_in_b,hull_b);
b_in_a = inhull(points_b_in_a,hull_a);
sum(a_in_b)
sum(b_in_a)
intersection_points = [];
for i = 1 : size(a_in_b,1)
    if(a_in_b(i) == 1)
        intersection_points = [intersection_points;points_a_in_b(i,:)];
    end
end
for i = 1 : size(b_in_a,1)
    if(b_in_a(i) == 1)
        intersection_points = [intersection_points;points_b_in_a(i,:)];
    end
end
if(size(intersection_points,1) > 2)
    [K_int,V_int] = convhull(intersection_points);
else
    V_int = 0;
end
size(intersection_points)
% Va
% Vb
% V_int
p_index = sqrt((1-V_int/Va)*(1-V_int/Vb));
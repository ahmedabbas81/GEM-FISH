function [loop_distances,control_distances3,loop_distances3] = get_loop_distances2(loops,resolution,high_res_distances,tad_positions)
%control_distances = zeros(size(tad_positions,1),1000);
counters = ones(size(tad_positions,1));
counters_loops = ones(size(tad_positions,1));
loop_distances = zeros(size(loops,1),2);
counter_loops = 1;
counter_controls = 1;
for i = 1 : size(loops,1)
    bp1 = loops(i,1);
    bp1_dash = loops(i,2);
    bp2 = loops(i,3);
    bp2_dash = loops(i,4);
    flag_bp1 = 0;
    flag_bp2 = 0;
    ind1 = -1;
    ind2 = -1;
    ind1_tad = -1;
    ind2_tad = -1;
%     ind1 = ceil(bp1*1.0/resolution);
%     ind2 = ceil(bp2*1.0/resolution);
    for i1 = 1 : size(reduced_positions,1)
        if((bp1 >= reduced_positions(i1,1) && bp1 < reduced_positions(i1,2)) || (bp1_dash >= reduced_positions(i1,1) && bp1_dash < reduced_positions(i1,2)))
            ind1 = i1;
            for itad = 1 : size(tad_positions,1)
                if((bp1 >= tad_positions(itad,1) && bp1 < tad_positions(itad,2)) || (bp1_dash >= tad_positions(itad,1) && bp1_dash < tad_positions(itad,2)))
                    ind1_tad = itad;
                    break;
                end
            end
            break;
        end
    end
    for i1 = 1 : size(reduced_positions,1)
        if((bp2 >= reduced_positions(i1,1) && bp2 < reduced_positions(i1,2)) || (bp2_dash >= reduced_positions(i1,1) && bp2_dash < reduced_positions(i1,2)))
            ind2 = i1;
            for itad = 1 : size(tad_positions,1)
                if((bp2 >= tad_positions(itad,1) && bp2 < tad_positions(itad,2)) || (bp2_dash >= tad_positions(itad,1) && bp2_dash < tad_positions(itad,2)))
                    ind2_tad = itad;
                    break;
                end
            end
            break;
        end
    end
    
    if(ind1 ~= -1 && ind2 ~= -1)
        if(ind2 > ind1)
            ind3 = max(1,ind1 - abs(ind2-ind1));
        else
            ind3 = min(size(reduced_positions,1),ind1 + abs(ind2-ind1));
        end
        if(abs(abs(reduced_positions(ind3,1) - reduced_positions(ind1,1)) - abs(reduced_positions(ind2,1) - reduced_positions(ind1,1)))>5000)
            if(ind2 > ind1)
                ind3 = min(size(reduced_positions,1),ind2 + abs(ind2-ind1));
            else
                ind3 = max(1,ind2 - abs(ind2-ind1));
            end
        end
        if(abs(abs(reduced_positions(ind3,1) - reduced_positions(ind2,1)) - abs(reduced_positions(ind2,1) - reduced_positions(ind1,1)))>5000  &&  abs(abs(reduced_positions(ind3,1) - reduced_positions(ind1,1)) - abs(reduced_positions(ind2,1) - reduced_positions(ind1,1)))>5000)
            continue;
        end
        loop_distances(i,1) = high_res_distances(ind1,ind2);
        %loop_distances(i,2) = abs(ind2_tad - ind1_tad);
        loop_distances2(i,1) = abs(reduced_positions(ind2,1) - reduced_positions(ind1,1));%abs(loops(i,3) - loops(i,1));
        %loop_distances(i,4) = (1.0*loop_distances(i,3))/loop_distances(i,1);
        loop_distances(i,2) = high_res_distances(ind1,ind3);
        loop_distances2(i,2) = abs(reduced_positions(ind3,1) - reduced_positions(ind1,1));
        index = abs(ind2_tad - ind1_tad) + 1;
        inner_loop_index = counters_loops(index);
%        loop_distances_output(index,inner_loop_index) = (1.0*loop_distances(i,3))/loop_distances(i,1);
        loop_distances3(counter_loops) = loop_distances2(i,1)*1.0/loop_distances(i,1);
        control_distances3(counter_loops) = loop_distances2(i,2)*1.0/loop_distances(i,2);
        counter_loops = counter_loops+1;
        counters_loops(index) = counters_loops(index) + 1;
        inner_index = counters(index);
%         if(inner_index > 5000)
%             continue;
%         end
        %%%get control distances at same genomic distance and same tad
        %%%separation
%         for i1 = 1 : size(high_res_distances,1)
%             for j1 = 1 : size(high_res_distances,2)
%                 if(abs(i1-j1) == abs(ind1-ind2))
%                     bp1 = reduced_positions(i1);
%                     bp2 = reduced_positions(j1);
%                     tad1_control = -1;
%                     tad2_control = -1;
%                     for itad = 1 : size(tad_positions,1)
%                         if(bp1 >= tad_positions(itad,1) && bp1 < tad_positions(itad,2))
%                             tad1_control = itad;
%                             break;
%                         end
%                     end
%                     for itad = 1 : size(tad_positions,1)
%                         if(bp2 >= tad_positions(itad,1) && bp2 < tad_positions(itad,2))
%                             tad2_control = itad;
%                             break;
%                         end
%                     end
%                     if((i1 ~= ind1 && j1 ~= ind2) && (i1 ~= ind2 && j1 ~= ind1) && abs(tad1_control - tad2_control) == abs(ind2_tad - ind1_tad))% && tad1_control == ind1_tad)%  abs(ind2_tad - ind1_tad) && 
%                         control_distances(index,inner_index) = (1.0*loop_distances(i,3))/high_res_distances(i1,j1);%(1.0*abs(loops(i,3) - loops(i,1)))/high_res_distances(i1,j1);
%                         control_distances2(counter_controls) = (1.0*loop_distances(i,3))/high_res_distances(i1,j1);
%                         counter_controls = counter_controls+1;
%                         counters(index) = counters(index)+1;
%                         inner_index = counters(index); 
%                     end
%                 end
%             end
%         end
                        
    end
end

        
    
            
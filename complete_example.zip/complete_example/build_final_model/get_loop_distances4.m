function [loop_distances,control_distances3,loop_distances3,loop_distances4] = get_loop_distances2(loops,reduced_positions,high_res_distances,tad_positions,resolution)
%control_distances = zeros(size(tad_positions,1),1000);
counters = ones(size(tad_positions,1));
counters_loops = ones(size(tad_positions,1));
loop_distances = zeros(size(loops,1),2);
counter_loops = 1;
counter_controls = 1;
for i = 1 : size(loops,1)
    bp1 = loops(i,1);
    bp1_dash = loops(i,2);
    bp2 = loops(i,3);
    bp2_dash = loops(i,4);
    flag_bp1 = 0;
    flag_bp2 = 0;
    ind1 = -1;
    ind2 = -1;
    ind1_tad = -1;
    ind2_tad = -1;
    
    for i1 = 1 : size(reduced_positions,1)
        if((bp1 >= reduced_positions(i1,1) && bp1 < reduced_positions(i1,2)) || (bp1_dash >= reduced_positions(i1,1) && bp1_dash < reduced_positions(i1,2)))
            ind1 = i1;
            for itad = 1 : size(tad_positions,1)
                if((bp1 >= tad_positions(itad,1) && bp1 < tad_positions(itad,2)) || (bp1_dash >= tad_positions(itad,1) && bp1_dash < tad_positions(itad,2)))
                    ind1_tad = itad;
                    break;
                end
            end
            break;
        end
    end
    for i1 = 1 : size(reduced_positions,1)
        if((bp2 >= reduced_positions(i1,1) && bp2 < reduced_positions(i1,2)) || (bp2_dash >= reduced_positions(i1,1) && bp2_dash < reduced_positions(i1,2)))
            ind2 = i1;
            for itad = 1 : size(tad_positions,1)
                if((bp2 >= tad_positions(itad,1) && bp2 < tad_positions(itad,2)) || (bp2_dash >= tad_positions(itad,1) && bp2_dash < tad_positions(itad,2)))
                    ind2_tad = itad;
                    break;
                end
            end
            break;
        end
    end
    
    if(ind1 == -1 || ind2 == -1)
        continue;
    else
        
        g_dist = abs(reduced_positions(ind2,1) - reduced_positions(ind1,1));
        ind3 = -1;
        for k1 = 1 : size(reduced_positions,1)
            for itad = 1 : size(tad_positions,1)
                if((reduced_positions(k1,1) >= tad_positions(itad,1) && reduced_positions(k1,2) < tad_positions(itad,2)))
                    indk_tad = itad;
                    break;
                end
            end
            g_dist1 = abs(reduced_positions(k1,1) - reduced_positions(ind1,1));
            g_dist2 = abs(reduced_positions(k1,1) - reduced_positions(ind2,1));
                flag_1 = 0;

                if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist2)<resolution)
                    if(ind1_tad ~= ind2_tad && ind2_tad ~= indk_tad && abs(ind1_tad-ind2_tad) == abs(indk_tad-ind2_tad))
                        ind3 = k1;
                        ind4 = ind2;
                        flag_1 = 1;
                    elseif(ind1_tad == ind2_tad && ind2_tad == indk_tad)
                        ind3 = k1;
                        ind4 = ind2;
                        flag_1 = 1;
                    end
                    if(flag_1 == 1)
                        break;
                    end
                end
                if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist1)<resolution)
                    if(ind1_tad ~= ind2_tad && ind1_tad ~= indk_tad && abs(ind1_tad-ind2_tad) == abs(indk_tad-ind1_tad))
                        ind3 = k1;
                        ind4 = ind1;
                        flag_1 = 1;
                    elseif(ind1_tad == ind2_tad && ind1_tad == indk_tad)
                        ind3 = k1;
                        ind4 = ind1;
                        flag_1 = 1;
                    end
                    if(flag_1 == 1)
                        break;
                    end
                end
%                 if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist2)<=5000)
%                     ind3 = k1;
%                     ind4 = ind2;
%                     break;
%                 end
            end
            %continue;
        end
        if(ind3 == -1)
            continue;
        else
            for itad = 1 : size(tad_positions,1)
                    if((reduced_positions(ind3,1) >= tad_positions(itad,1) && reduced_positions(ind3,2) < tad_positions(itad,2)))
                        ind3_tad = itad;
                        break;
                    end
            end
                for itad = 1 : size(tad_positions,1)
                    if((reduced_positions(ind4,1) >= tad_positions(itad,1) && reduced_positions(ind4,2) < tad_positions(itad,2)))
                        ind4_tad = itad;
                        break;
                    end
                end
        end
        loop_distances(i,1) = high_res_distances(ind1,ind2);%spatial distance
        loop_distances2(i,1) = abs(reduced_positions(ind2,1) - reduced_positions(ind1,1));%genomic distance
        loop_distances(i,2) = high_res_distances(ind3,ind4);
        loop_distances2(i,2) = abs(reduced_positions(ind3,1) - reduced_positions(ind4,1));
        index = abs(ind2_tad - ind1_tad) + 1;
        inner_loop_index = counters_loops(index);
%       loop_distances_output(index,inner_loop_index) = (1.0*loop_distances(i,3))/loop_distances(i,1);
        loop_distances3(counter_loops) = loop_distances2(i,1)*1.0/loop_distances(i,1);
        loop_distances4(counter_loops,1) = ind1;
        loop_distances4(counter_loops,2) = ind2;
        loop_distances4(counter_loops,3) = bp1;
        loop_distances4(counter_loops,4) = bp2;
        loop_distances4(counter_loops,5) = abs(reduced_positions(ind1,1)-reduced_positions(ind2,1));
        loop_distances4(counter_loops,6) = loop_distances(i,1);
        loop_distances4(counter_loops,7) = ind3;
        loop_distances4(counter_loops,8) = ind4;
        loop_distances4(counter_loops,9) = abs(reduced_positions(ind3,1)-reduced_positions(ind4,1));
        loop_distances4(counter_loops,10) = loop_distances(i,2);
        loop_distances4(counter_loops,11) = ind1_tad;
        loop_distances4(counter_loops,12) = ind2_tad;
        loop_distances4(counter_loops,13) = ind3_tad;
        loop_distances4(counter_loops,14) = ind4_tad;
        control_distances3(counter_loops) = loop_distances2(i,2)*1.0/loop_distances(i,2);
        counter_loops = counter_loops+1;                
    end
end

        
    
            
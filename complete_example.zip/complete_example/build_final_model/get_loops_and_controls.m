function get_loops_and_controls(l_file,c_file,dir_name)
l = csvread(l_file);
c = load(c_file);
l = l/1000;
c = c/1000;
filename = sprintf('%s/rank_sum.txt',dir_name);
fid = fopen(filename,'w');
for i = 1 : size(l,1)
    filename = sprintf('%s/loop_tads_%d.csv',dir_name,i-1);
    l1 = find(l(i,:)>0);
    l2 = l(i,l1);
    csvwrite(filename,l2);
    m_l(i) = median(l2)
    filename = sprintf('%s/controls_tads_%d.csv',dir_name,i-1);
    c1 = find(c(i,:)>0);
    c2 = c(i,c1);
    [p1,h1] = ranksum(l2,c2,'tail','right');
    [p2,h2] = ranksum(l2,c2);%,'tail','right');
    fprintf(fid,'diff in tads = %d, number of loop distances = %d, number of control distances = %d, \np-value right tail = %.2e \np-value no tail = %.2e',size(l2,2),size(c2,2),p1,p2);

    csvwrite(filename,c2);
    C = [l2 c2];
    grp = [zeros(size(l2)) ones(size(c2))];
    figure,
    
    boxplot(C,grp,'labels',{'loop distances','control distances'},'symbol','');
    
    ylim([0 max(quantile(l2,0.8)*2,quantile(c2,0.8)*2)]);
    t = sprintf('num of control distances = %d\nnumber of loop distances = %d\np-value right tail = %.2e \np-value no tail = %.2e',size(c2,2),size(l2,2),p1,p2);
    title(t,'FontWeight','normal');
    ylabel('Density (kb/nm)')
    filename = sprintf('%s/boxplot_density1.png',dir_name);
    saveas(gcf,filename);
    %close
    figure,
    
    boxplot(C,grp,'labels',{'loop loci','control loci'},'symbol','');
    
    ylim([0 max(quantile(l2,0.8)*2,quantile(c2,0.8)*2)]);
    %t = sprintf('num of control distances = %d\nnumber of loop distances = %d\np-value right tail = %.2e \np-value no tail = %.2e',size(c2,2),size(l2,2),p1,p2);
    %title(t,'FontWeight','normal');
    ylabel('Density (kb/nm)')
    filename = sprintf('%s/boxplot_density_final.png',dir_name);
    saveas(gcf,filename);
    close
    m_c(i) = median(c2)
    fprintf(fid,'diff in tads = %d, number of loop distances = %d, number of control distances = %d, \np-value right tail = %.2e \np-value no tail = %.2e',size(l2,2),size(c2,2),p1,p2);
    f_name = sprintf('%s/loops_and_controls.mat',dir_name);
    save(f_name,'l2','c2');
    clear l1 l2 c1 c2
end
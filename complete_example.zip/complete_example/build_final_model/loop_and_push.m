function [h_r_structure,label] = loop_and_push(C,s,s_index,h_r_structure,label,N,n_rec)
size1 = s_index.size();
if(n_rec > 400)
    %label = label + 1;
    return;
end
n_rec = n_rec + 1;
tmp = s.top();
V1 = cell2mat(tmp);
ind = cell2mat(s_index.top());
flag = 0;
for j = 1 : length(C)
    flag = 0;
    tmp = C(j);
    V2 = cell2mat(tmp);
    if(h_r_structure(j,5) == N && j ~= ind)
        for k1 = 1 : length(V1)-1
            v1 = V1(k1);
            v2 = V1(k1+1);
            for k2 = 1 : length(V2)-1
                v1_dash = V2(k2);
                v2_dash = V2(k2+1);
                if(v1 == v1_dash && v2 == v2_dash)
                    flag = 1;
                    break;
                end
            end
            if(flag == 1)
                break;
            end
        end
        if(flag == 1)
            s.push(C(j));
            s_index.push(num2cell(j));
            h_r_structure(j,5) = 0;
            h_r_structure(j,6) = label;
            [h_r_structure,label] = loop_and_push(C,s,s_index,h_r_structure,label,N,n_rec);
        end
        
            
         
    end
    if(flag == 1)
        break;
    end
end
if(flag == 0 && s_index.size()>1)
    s.pop();
    s_index.pop();
    h_r_structure(ind,5) = 0;
    h_r_structure(ind,6) = label;
    if(n_rec >= 400)
        while(s.size()>0)
            s.pop();
            s_index.pop();
            %tmp = s_index.top();
        end
        %label = label + 1;
        return;
    end
    [h_r_structure,label] = loop_and_push(C,s,s_index,h_r_structure,label,N,n_rec);
elseif(flag == 0 && s_index.size() == 1)
    s.pop();
    s_index.pop();
    h_r_structure(ind,5) = 0;
    h_r_structure(ind,6) = label;
    %label = label+1;
    return;
end


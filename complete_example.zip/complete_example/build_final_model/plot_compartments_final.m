function plot_compartments_final(original,hic_fish,hic,dir_name,file_name,high_resolution_distances,volumes_ind,GL_ind)
coeffs_original = pca(original);
orig_coef = coeffs_original(:,1);
X1_O = coeffs_original(:,1);
X1_O(X1_O<0) = 0;
X2_O = coeffs_original(:,1);
X2_O(X2_O>0) = 0;

figure('units','normalized','outerposition',[0 0 1 0.6]);
fname = sprintf('%s/errors_comp_assignment.txt',dir_name);
%fname = 'errors_comp_assignment.txt';
fid = fopen(fname,'w');
max_limit = max(X1_O);
min_limit = min(X2_O);
%xticks([1 : 3 : size(X1,1)])
coeffs_hic_fish = pca(hic_fish);
hic_fish_coef = coeffs_hic_fish(:,1);
%%calculate errors
[n, e] = calculate_errors(orig_coef,hic_fish_coef);
fprintf(fid,'number of errors in hic_fish = %d\n',n);
for i = 1 : length(e)
    fprintf(fid,'error in TAD %d, value in original = %.3f, value in calculated = %.3f\n', e(i),orig_coef(e(i)),hic_fish_coef(e(i)));
end
fprintf(fid,'===================================================');   
X1_F = coeffs_hic_fish(:,1);
X1_F(X1_F<0) = 0;
X2_F = coeffs_hic_fish(:,1);
X2_F(X2_F>0) = 0;

intra_comp = [];
inter_comp = [];
for i = 1 : length(X1_F)
    for j = 1 : length(X1_F)
        if(i ~= j && X1_F(i) ~= 0 && X1_F(j) ~= 0)
            intra_comp = [intra_comp;high_resolution_distances(i,j)];
        end
        if(i ~= j && (X1_F(i) ~= 0 && X1_F(j) == 0 || X1_F(i) == 0 && X1_F(j) ~= 0))
            inter_comp = [inter_comp;high_resolution_distances(i,j)];
        end
    end
end
for i = 1 : length(X2_F)
    for j = 1 : length(X2_F)
        if(i ~= j && X2_F(i) ~= 0 && X2_F(j) ~= 0)
            intra_comp = [intra_comp;high_resolution_distances(i,j)];
        end
    end
end

    grp = [];
    C = [];
    for i = 1 : size(inter_comp,1)
        grp = [grp,0];
        C = [C,inter_comp(i)];
    end
    for i = 1 : size(intra_comp,1)
        grp = [grp,1];
        C = [C,intra_comp(i)];
    end
    %grp = [zeros(size(inter_comp,1)); ones(size(intra_comp,1))];
    figure,
    
    boxplot(C,grp,'labels',{'inter_comp distances','intra_comp distances'},'symbol','');
    
    ylim([0 max(quantile(inter_comp,0.8)*2,quantile(intra_comp,0.8)*2)]);
%     t = sprintf('num of control distances = %d\nnumber of loop distances = %d\np-value right tail = %.2e \np-value no tail = %.2e',size(c2,2),size(l2,2),p1,p2);
%     title(t,'FontWeight','normal');
    ylabel('distance (nm)')
    filename = sprintf('%s/comp_boxplot.png',dir_name);
    saveas(gcf,filename);
    close
    filename = sprintf('%s/pvalues.txt',dir_name);
    fid_p = fopen(filename,'w');
%     fprintf(fid_p,'p distances = %.3e',p1);
%     [p2,h2] = ranksum(Density_A,Density_B);%,'tail','right');
%     grp = [];
%     C = [];
%     for i = 1 : size(Density_A,1)
%         grp = [grp,0];
%         C = [C,Density_A(i)];
%     end
%     for i = 1 : size(Density_B,1)
%         grp = [grp,1];
%         C = [C,Density_B(i)];
%     end
%     %grp = [zeros(size(inter_comp,1)); ones(size(intra_comp,1))];
%     figure,
%     
%     boxplot(C,grp,'labels',{'Density-A','Density-B'},'symbol','');
%     
%     ylim([0 max(quantile(Density_A,0.8)*2,quantile(Density_B,0.8)*2)]);
% %     t = sprintf('num of control distances = %d\nnumber of loop distances = %d\np-value right tail = %.2e \np-value no tail = %.2e',size(c2,2),size(l2,2),p1,p2);
% %     title(t,'FontWeight','normal');
%     ylabel('density (Mb/um)')
%     filename = sprintf('%s/density_boxplot.fig',dir_name);
%     saveas(gcf,filename);
%     close
%     
%     fprintf(fid_p,'p density = %.3e',p2);
% %xticks([1 : 3 : size(X1,1)])
% %title2_new = sprintf('%s\nerrors = %d',title2,n);
% max_limit = max(max(X1_F),max_limit);
% min_limit = min(min(X2_F),min_limit);
% %%%%%%%%%%%%%%%%%%%%%%%%
% 
% % coeffs_hic_fish_high_resolution = pca(hic_fish_high_resolution);
% % hic_fish_high_resolution_coef = coeffs_hic_fish_high_resolution(:,1);
% % [n, e] = calculate_errors(orig_coef,hic_fish_high_resolution_coef);
% % X1 = coeffs_hic_fish_high_resolution(:,1);
% % X1(X1<0) = 0;
% % X2 = coeffs_hic_fish_high_resolution(:,1);
% % X2(X2>0) = 0;
% % subplot(2,2,3)
% % bar(X1,'r');
% % hold
% % bar(X2,'b');
% % %xticks([1 : 3 : size(X1,1)])
% % title3_new = sprintf('%s\nerrors = %d',title3,n);
% % title(title3_new)
% 
% 
coeffs_hic = pca(hic);
hic_coef = coeffs_hic(:,1);
[n, e] = calculate_errors(orig_coef,hic_coef);
fprintf(fid,'number of errors in hic = %d\n',n);
for i = 1 : length(e)
    fprintf(fid,'error in TAD %d, value in original = %.3f, value in calculated = %.3f\n', e(i),orig_coef(e(i)),hic_coef(e(i)));
end
X1 = coeffs_hic(:,1);
X1(X1<0) = 0;
X2 = coeffs_hic(:,1);
X2(X2>0) = 0;
% f_name = sprintf('%s/compartments.mat',dir_name);
% save(f_name,'X1_O','X2_O','X1_F','X2_F','X1','X2');%X1_O 
% f_name = sprintf('%s/densities.mat',dir_name);
% save(f_name,'Density_A','Density_B');
% f_name = sprintf('%s/inter_intra_comp_distances.mat',dir_name);
% save(f_name,'inter_comp','intra_comp');
% max_limit = max(max(X1),max_limit);
% min_limit = min(min(X2),min_limit);
%xticks([1 : 3 : size(X1,1)])
%title4_new = sprintf('%s\nerrors = %d',title4,n);
%subplot(1,3,1)
%figure('units','normalized','outerposition',[0 0 0.8 0.52])
subplot(1,2,1)
%figure('units','pixels','outerposition',[0 0 380 380]);
bar(X1_O,'r');
hold
bar(X2_O,'b');
xlim([0 size(X1,1)+1])
ylim([min_limit-0.02 max_limit+0.02])
xlabel('TAD #')
ylabel('Principal component coefficient')
hold
subplot(1,2,2)
bar(X1_F,'r');
hold
bar(X2_F,'b');
xlim([0 size(X1,1)+1])
ylim([min_limit-0.02 max_limit+0.02])
xlabel('TAD #')
ylabel('Principal component coefficient')
filename = sprintf('./%s/%s_hic_fish.png',dir_name,file_name);
saveas(gcf,filename);
filename = sprintf('./%s/%s_hic_fish.fig',dir_name,file_name);
saveas(gcf,filename);
close
figure,
bar(X1_F,'r');
hold
bar(X2_F,'b');
xlim([0 size(X1,1)+1])
ylim([min_limit-0.02 max_limit+0.02])
xlabel('TAD #')
ylabel('Principal component coefficient')
filename = sprintf('./%s/%s_hic_fish.png',dir_name,file_name);
saveas(gcf,filename);
close
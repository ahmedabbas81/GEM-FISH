function plot_three_figures_final_bluewhitered(first_mat,second_mat,third_mat,dir_name,file_name)
min1 = min(min(min(first_mat)),min(min(second_mat)));
bottom = min(min1,min(min(third_mat)));
max1 = max(max(max(first_mat)),max(max(second_mat)));
top = max(max1,max(max(third_mat)));
figure('units','normalized','outerposition',[0 0 1 0.52])
subplot(1,3,1)
imagesc(first_mat);
xlabel('Number of TAD')
ylabel('Number of TAD')
colormap(bluewhitered)
title('A')
%set(gca, 'units','normalized','OuterPosition', [0.03, 0.05, 0.3, 0.3])
caxis manual
caxis([bottom top])
subplot(1,3,2)
imagesc(second_mat);
colormap(bluewhitered)
title('B')
xlabel('Number of TAD')
ylabel('Number of TAD')

%set(gca,'units','normalized', 'OuterPosition', [0.35, 0.05, 0.3, 0.3])
caxis manual
caxis([bottom top])
handle = subplot(1,3,3)
imagesc(third_mat);
xlabel('Number of TAD')
ylabel('Number of TAD')

title('C')
%set(gca, 'units','normalized','OuterPosition', [0.67, 0.05, 0.3, 0.3])
caxis manual
caxis([bottom top])
colormap(bluewhitered)
p = get(handle,'position');
colorbar('location','Manual','position', [p(1)+p(3)+0.02 p(2) 0.015 p(4)]);
filename = sprintf('./%s/%s.fig',dir_name,file_name);
saveas(gcf,filename); 
close


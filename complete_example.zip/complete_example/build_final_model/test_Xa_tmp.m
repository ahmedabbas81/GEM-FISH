%clear all
score_flag = 2;
date = 'Oct-21th-test'
plot_figures = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


chr_num = 23;
chr_num_string = 'Xa';
ntads = 40;
g_s_exp = 0.22;
resolution = 40E3;
get_high_res_and_test(chr_num,chr_num_string,ntads,g_s_exp,resolution,plot_figures,score_flag,date)

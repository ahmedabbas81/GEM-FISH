function [fish_corr] = test_high_resolution_structure(out_dir_name, tads_positions_filename, nTADs, a_coef, exponent_relation, fish_distances_file, hic_structure, hic_fish_structure,high_resolution_distances,Xa_flag,flag_plotting,volumes_ind,diameters_ind,GL_ind)
%%,p_fit_exp,p_coef,q_fit_exp,q_coef]
tad_positions = load(tads_positions_filename);
%mkdir(out_dir_name);
Data1 = csvread(fish_distances_file);
filename = sprintf('./%s/Information.txt',out_dir_name);
fid_stats = fopen(filename,'w');
    
Data1 = Data1*1000;
Data = Data1;


TAD_Est_Dist = zeros(nTADs, nTADs);
relative_error = zeros(nTADs, nTADs);
k1 = 1;
for i = 1 : nTADs
    i1 = i;
    startI = tad_positions(i1,1);
    endI = tad_positions(i1,2);
    midI = (startI+endI)/2;
    for j1 = 1 : nTADs
        j2 = j1;
        sj = tad_positions(j2,1);
        ej = tad_positions(j2,2);
        mid = (sj+ej)/2;
        g_dist = abs(mid - midI);
        TAD_Est_Dist(i1,j2) =1000* a_coef*(g_dist)^exponent_relation;
        if(Data(i1,j2) ~= 0 && g_dist ~= 0)
            spatial_distances(k1,1) = Data1(i1,j2);
            genomic_distances(k1,1) = g_dist;%/1E7;
            k1 = k1 + 1;
        end
    end
end
csvwrite('xi_estimated_notdivide.csv',TAD_Est_Dist);
[fun,gof] = fit((genomic_distances),(spatial_distances),'power1');
%P=polyfitZero(log10(genomic_distances),log10(spatial_distances),1);
%return;
fitvalues=coeffvalues(fun);
%if(flag_plotting)
    
%end
offset = 0;
Data1 = csvread(fish_distances_file);
Data1 = Data1*1000;
Data = Data1;
hic_global_structure = load(hic_structure);
hic_fish_global_structure = load(hic_fish_structure);
hic_global_structure = hic_global_structure;
hic_fish_global_structure = hic_fish_global_structure;
high_resolution_distances = high_resolution_distances;
distances_hic_fish = squareform(pdist(hic_fish_global_structure(:,:)));
distances_hic = squareform(pdist(hic_global_structure(:,:)));

sum_re_diag = 0;
sum_re_diag_high = 0;
sum_re_diag_hic = 0;
sum_re = 0;
sum_re_hic = 0;
sum_re_high_resolution = 0;
count_re = 0;
count_diag = 0;
for i = 1 : size(Data,1)
    for j = 1 : size(Data,2)
        if(Data(i,j) ~= 0)
            relative_error(i,j) = abs(Data(i,j) - distances_hic_fish(i,j))/Data(i,j);
            relative_error_high_resolution(i,j) = abs(Data(i,j) - high_resolution_distances(i,j))/Data(i,j);
            relative_error_hic(i,j) = abs(Data(i,j) - distances_hic(i,j))/Data(i,j);
            sum_re = sum_re + relative_error(i,j);
            sum_re_high_resolution = sum_re_high_resolution + relative_error_high_resolution(i,j);
            sum_re_hic = sum_re_hic + relative_error_hic(i,j);
            count_re = count_re + 1;
            if((j - i) == 1)
                sum_re_diag = sum_re_diag + relative_error(i,j);
                sum_re_diag_high = sum_re_diag_high + relative_error_high_resolution(i,j);
                sum_re_diag_hic = sum_re_diag_hic + relative_error_hic(i,j);
                
                count_diag = count_diag + 1;
                diag_low_res(count_diag) = relative_error(i,j);
                diag_high_res(count_diag) = relative_error_high_resolution(i,j);
            end
        end
    end
end

norm_original = ones(nTADs, nTADs);
norm_hic = ones(nTADs, nTADs);
norm_hic_fish = ones(nTADs, nTADs);
norm_hic_fish_high_resolution = ones(nTADs,nTADs);
for i = 1 : nTADs
    for j = 1 : nTADs
        if(TAD_Est_Dist(i,j) ~= 0)
            norm_original(i,j) = Data(i,j)/TAD_Est_Dist(i,j);
            norm_hic(i,j) = distances_hic(i,j)/TAD_Est_Dist(i,j);
            norm_hic_fish(i,j) = distances_hic_fish(i,j)/TAD_Est_Dist(i,j);
            norm_hic_fish_high_resolution(i,j) = high_resolution_distances(i,j)/TAD_Est_Dist(i,j);
        end
    end
end
% f_name = sprintf('%s/normalized_distance_matrices.mat',out_dir_name)
% save(f_name,'norm_original','norm_hic','norm_hic_fish','norm_hic_fish_high_resolution');

title1 = 'normalized FISH distances';
R1 = corrcoef(norm_original,norm_hic_fish);
title2 = sprintf('normalized Hi-C + FISH\nCC = %.2f',R1(1,2));
R1 = corrcoef(norm_original,norm_hic);
title3 = sprintf('normalized Hi-C\nCC = %.2f',R1(1,2));
dir_name = out_dir_name;
file_name = 'normalized_distances';
if(flag_plotting)
    %plot_three_figures_final(norm_original,norm_hic_fish,norm_hic,title1,title2,title3,dir_name,file_name);
    %plot_three_figures_final(norm_original,norm_hic_fish,norm_hic,dir_name,file_name);
    plot_two_figures_final(norm_original,norm_hic_fish,dir_name,file_name);
end

    dir_name = out_dir_name;
    file_name = 'compartments_correlation';
    file_name_original = 'original_comp_correlation.png';
    [exp_corr, fish_corr, hic_corr] = get_compartments(norm_original,norm_hic_fish_high_resolution,norm_hic,dir_name,file_name,1,high_resolution_distances,volumes_ind,GL_ind);
PCs_fish = pca(fish_corr);
PCs_hic = pca(hic_corr);
PCs = pca(exp_corr);
first_pc = PCs(:,1);
first_pc2 = PCs_fish(:,1);
first_pc3 = PCs_hic(:,1);
file_name = sprintf('%s/fish+hic',dir_name);
p_index_fish_hic = calc_polarization_index_2(first_pc,first_pc2,hic_fish_global_structure,file_name,out_dir_name);
file_name = sprintf('%s/hic_only',dir_name);
p_index_hic = calc_polarization_index_2(first_pc,first_pc3,hic_global_structure,file_name,out_dir_name);
filename = sprintf('./%s/polarization_indices.txt',dir_name);
fid = fopen(filename,'w');
fprintf(fid,'polarization index fish+hic = %.4f\n',p_index_fish_hic);
fprintf(fid,'polarization index hic = %.4f\n',p_index_hic);
fprintf('polarization index fish+hic = %.4f\n',p_index_fish_hic);
fprintf('polarization index hic = %.4f\n',p_index_hic);

    
%     dir_name = out_dir_name;
%     file_name = 'compartments_normalized';
%     file_name_original = 'original_comp_normalized.png';
%     get_compartments(norm_original,norm_hic_fish,norm_hic_fish_high_resolution,norm_hic,title1,title2,title3,title4,dir_name,file_name,file_name_original);

%getting compartments based on the fish original data


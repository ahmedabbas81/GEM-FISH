function threeD_to_2D_struct(threeD_object1,axis1,axis2,filename)
projected_surface1(:,1) = threeD_object1(:,axis1);
x1 = threeD_object1(:,axis1);
projected_surface1(:,2) = threeD_object1(:,axis2);
y1 = threeD_object1(:,axis2);
c1 = mean(x1(:));
c2 = mean(y1(:));

xaxis = [];
for i = min(x1) : max(x1)
    xaxis = [xaxis;[i,c2]];
end
yaxis = [];
for i = min(y1) : max(y1)
    yaxis = [yaxis;[c1,i]];
end

k1 = convhull(x1,y1);
figure,
plot(x1(k1),y1(k1),'c-',x1,y1,'b*')
hold
plot(xaxis(:,1),xaxis(:,2),'-r',yaxis(:,1),yaxis(:,2),'-r');
for i = 1 : size(x1,1)
    x = x1(i);
    y = y1(i);
    txt1 = sprintf('%d',i);
    text(x,y,txt1);
end
    
xlim([min(x1)-20 max(x1)+20])
ylim([min(y1)-20 max(y1)+20])
%file_name = sprintf('%s/%s.png',dirname,filename);
saveas(gcf,filename);
close
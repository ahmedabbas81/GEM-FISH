function threeD_to_2D_structure(threeD_object1,threeD_object2,axis1,axis2,filename)
projected_surface1(:,1) = threeD_object1(:,axis1);
x1 = threeD_object1(:,axis1);
projected_surface1(:,2) = threeD_object1(:,axis2);
y1 = threeD_object1(:,axis2);
projected_surface2(:,1) = threeD_object2(:,axis1);
x2 = threeD_object2(:,axis1);
projected_surface2(:,2) = threeD_object2(:,axis2);
y2 = threeD_object2(:,axis2);

figure,
plot(x1,y1,'b*')
saveas(gcf,filename);
close
function [ydata,proportions,C,C1,C2,C3] = BasicOptCell(ydata, P,loci,max_iter,M,lambdaE, lambdaF, fish_distances, a_coef,g_s_exp)
% added the following parameters
% lambdaF
% fish_distances
% g_s_exp: the exponent term in the genomic distance/spatial distance relation in the fish paper (from the paper)

% Basic optimizer cell
% If M = 1, it serves as an optimizer for average structure
% If M > 1, it serves as an optimizer for multiple conformations
% Some gradients refer to t-SNE (Laurens van der Maaten, 2008)
% See "Methods" in the paper of GEM for more 
% Suggests of better optimization are higly appreciated.

% Joint probability P in Hi-C space
P=P/sum(sum(P));
zeroP=find(P==0);         % Zero interactions
unzeroP=find(P>0);        % Non-zero iteractions
mmax=1E5;                 % Prevent the excessive value  
factor = 2;
% Coeffiencts
epsilonY = 100;           % Learning rate for Y
epsilonW =0;              % Learning rate for W (initialization)
changeflag=0;             % Whether epsilonW is changed
minerr=10^(-6);           % Optimization stops when cost function is less than minerr for some time which is counted by qcount                           
qcount=0;                                 

% Compute the spatial distance between two continuous loci
n=size(loci,1);
l=loci(2:n)-loci(1:n-1);
%l=l/sizepara ;  % commented this line from orinal GEM and will use the
%relation in the fish paper

% added this code by ahmed
for i = 1 : size(l,1)
    l(i) = 1000*a_coef*l(i)^g_s_exp;
end

% Initialization
weights=zeros(M,1);
proportions = exp(-weights);
proportions= proportions/sum(proportions);
dCdP = zeros(M,1);
dCdD = zeros(n,n,M);
dCdY = zeros(size(ydata));
y = zeros(size(ydata));
size(y);
% Optimization begins
for iter=1:max_iter
    
    % Compute the conformation energy and its gradient
    
    for m=1:M
        [ E,gE ] = Energy( ydata(:,:,m),l,n);
        tmpE(m)=E;                     
        tmpgE(:,:,m)=gE;
        %added by ahmed
        %compute the square and abs difference between fish distances and
        %calculated distances
        y = ydata(:,:,m);
        %size(y)
        calculated_distances = squareform(pdist(y(:,:)));
        %size(calculated_distances)
        for i = 1 : size(fish_distances,1)
            for j = 1 : size(fish_distances,1)
                if(i == j)
                    distances_diff(i,j) = 0;
                else
                    distances_diff(i,j) = calculated_distances(i,j) - fish_distances(i,j);
                end
            end
        end
        diff_m = distances_diff.^2;
        tmp_fish(m) = sum(sum(diff_m));
        tmp_fish_der(:,:,m) = calculate_derivative(y,fish_distances);
    end
    
    % Compute pairwise affinities per conformation
    %nothing to add here
    for m=1:M
    	sum_ydata = sum(ydata(:,:,m) .^ 2, 2);
    	tmp = 1 ./ (1 + bsxfun(@plus, sum_ydata, bsxfun(@plus, sum_ydata', -2 * ydata(:,:,m) * ydata(:,:,m)')));
    	tmp(zeroP)=0;
        tmp(1:n+1:end) = 0;                          % set diagonal to zero
        num(:,:,m) = tmp;
    end
        
    % Compute joint probability that point i and j are neighbors
    % nothing to add here
    QZ=zeros(n,n);
    for m=1:M
        QZ = QZ + proportions(m)*num(:,:,m);
    end
    Z = sum(QZ(:));        
    Q = QZ ./ Z;
    
    % Compute the gradient of C1 with respect to mixture proportions
    % add a component to dCdP
    QP = Q - P;
    for m=1:M
        tmp=(1 ./ QZ) .* QP.*num(:,:,m);
        % third component added by ahmed
        dCdP(m) = sum(sum(tmp(unzeroP)))+lambdaE*tmpE(m)+lambdaF*tmp_fish(m);
    end

    % Compute the gradient of C1 with respect to mixture weights
    % nothing to add here
    dCdW = proportions .* ( sum(dCdP .* proportions)-dCdP);

    % Compute the gradient of C1 with respect to pairwise distances
    % nothing to add here
    for m=1:M
    	tmp = proportions(m)*( -QP) .* num(:,:,m).* num(:,:,m)./ QZ;
        tmp(zeroP)=0;
        dCdD(:,:,m)=tmp;
    end
    
    % Compute the gradient of C with respect to the coordinate
    for m=1:M
        for i=1:n
            dCdY(i,:,m) = 4*sum(bsxfun(@times, dCdD(:,i,m),bsxfun(@minus, ydata(i,:,m), ydata(:,:,m))), 1);
        end
        % third component added by ahmed
        dCdY(:,:,m)=dCdY(:,:,m)+lambdaE*proportions(m)*tmpgE(:,:,m)+lambdaF*proportions(m)*tmp_fish_der(:,:,m);
    end
    
    % Cost
    % C: Total cost (C1+lambda_E*C2+lambdaF*C3)                           
    % C1: Data cost (KL divergence)                           
    % C2: Energy cost (Conformation energy)
    % C3 added by ahmed (fish component)
    C2=0;
    C3=0;
    for m=1:M
        C2=C2+proportions(m)*tmpE(m);
        C3=C3+proportions(m)*tmp_fish(m);
    end 
    % third component added by ahmed
    C = sum(P(unzeroP) .* log(P(unzeroP) ./ Q(unzeroP)))+lambdaE*C2+lambdaF*C3;
    C1=C-lambdaE*C2-lambdaF*C3;
    if iter==1
        pC=C;
    end
    
    % Find a local optimal solution using adaptive learning rate
    if  C>pC
        epsilonY=epsilonY*0.9;
        epsilonW=epsilonW*0.9;
        ydata=pydata;
        weights=pweights;
        proportions=pproportions;
        continue;
    else
        if pC-C<minerr
            qcount=qcount+1;
        else
            qcount=0;
        end
%         if~rem(iter,1E4)
%             factor = factor + 0.01;
%         end
        if~rem(iter, 100)
            epsilonY=epsilonY*factor;
        end
        pC=C;
    end
    
    if qcount>10 && epsilonY<1
        break;
    end
    
    if ~rem(iter, 100)
        %disp(['Iteration ' num2str(iter) ': C is ' num2str(C) ', C1 is ' num2str(C1) ', C2 is ' num2str(C2) ', C3 is ' num2str(C3) ]);
        
    end
    if ~rem(iter, 100000)
        save('ydata.mat','ydata','C3');
        clc;
    end
    if C1<0.2
        changeflag=1;
    end
    if changeflag
        epsilonW=1;
    end
    
    pydata=ydata;
    pweights=weights;
    
    pproportions=proportions;
    if iter~=max_iter    
        ydata=ydata-epsilonY*dCdY;
        ydata = bsxfun(@minus, ydata, mean(ydata, 1));
        weights = weights - epsilonW * dCdW;
        proportions = exp(-weights);
        proportions(proportions>mmax)=mmax;
        proportions= proportions/sum(proportions);
    end
end
end
function GEM_FISH_TAD_level(HiC_file,loci_file,max_iter,lambdaE,infer_latent,lambdaF,fish_distances,a_coef,g_s_exp,out_directory)
disp('reading Hi-C map and loci files');
X=load(HiC_file);
loci=load(loci_file);
X=X-diag(diag(X));

disp('Calculating TAD-level 3D model');
disp('may take several minutes');
M = 1;
[structure,proportions,C,C1,C2,C3]=Optimizer(X,loci,max_iter,M,lambdaE,lambdaF,fish_distances,a_coef,g_s_exp);
if M>1
    for i=1:M
        [ RMSE,structure(:,:,i) ] = SVD3D( structure(:,:,i),structure(:,:,1) );
    end
end
% Output reconstructed structure to 'conformation[1-M].txt'
for m=1:M
    dlmwrite(['./' out_directory '/conformation' num2str(m) '.txt'],structure(:,:,m),'delimiter', '\t','precision','%6.4f');
end
disp (['The reconstructed conformation is written to ./' out_directory '/conformation1.txt']);

% ------------------- Latent function  -------------------- %
% Capture the latent function by comparing the modeled      %
% structures with the original Hi-C data.                   %
% --------------------------------------------------------- %
if infer_latent==1
    LatentFunction( X(index,index),structure,M,proportions );
end

%disp('=================================================================');



end

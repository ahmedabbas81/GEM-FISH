function calculate_avg_fish_distances(coordinates_filename,n_tads,n_cells,out_fname)
coordinates = xlsread(coordinates_filename);
Average_distances = zeros(n_tads, n_tads);
variances = zeros(n_tads, n_tads);
for i = 1 : n_cells
    for j = 1 : n_tads
        for k = 1 : n_tads
            j1 = j;
            k1 = k;
            if(isnan(coordinates((i-1)*n_tads +j, 3)) || isnan(coordinates((i-1)*n_tads +k, 3)))
                spatial_distances(i, j1, k1) = -10;
                continue;
            end
            if(j == k)
                spatial_distances(i, j1, k1) = 0;
                continue;
            end
            x1 = coordinates((i-1)*n_tads +j, 3);
            y1 = coordinates((i-1)*n_tads +j, 4);
            z1 = coordinates((i-1)*n_tads +j, 5);
            
            x2 = coordinates((i-1)*n_tads +k, 3);
            y2 = coordinates((i-1)*n_tads +k, 4);
            z2 = coordinates((i-1)*n_tads +k, 5);
            
            d = sqrt((x1 - x2)^2 + (y1 - y2)^2 + (z1 - z2)^2);
            
            spatial_distances(i, j1, k1) = d;
        end
    end
end

for j = 1 : n_tads
    for k = 1 : n_tads
        j1 = j;
        k1 = k;
        if(j == k)
            Average_distances(j1, k1) = 0;
            variances(j1, k1) = 0;
            continue;
        end
        sum = 0;
        n_distances = 0;
        count = 1;
        d = [];
        for i = 1 :n_cells
            if(spatial_distances(i, j1, k1) == -10)
                continue;
            end
            sum = sum + spatial_distances(i, j1, k1);
            d = [d;spatial_distances(i, j1, k1)];
            n_distances = n_distances + 1;
        end
        sum = sum/n_distances;
        Average_distances(j1, k1) = sum;
        variances(j1,k1) = var(d);
    end
end
csvwrite(out_fname,Average_distances);

function der = calculate_derivative(ydata, fish_distances)
n_points = size(ydata,1);
dim = size(ydata,2);
der = zeros(n_points, dim);

for i = 1 : size(fish_distances,1)%n_points
    sum_i = 0; 
    for j = 1 : size(fish_distances,1)%n_points
        if(i == j || fish_distances(i,j) == 0)
            continue;
        end
        distance_norm = norm(ydata(i,:) - ydata(j,:));
        diff = ydata(i,:) - ydata(j,:);
        factor = 2*(distance_norm - fish_distances(i,j))/distance_norm;
        der(i,:) = der(i,:) + diff.*factor;
        
    end
    
        
end
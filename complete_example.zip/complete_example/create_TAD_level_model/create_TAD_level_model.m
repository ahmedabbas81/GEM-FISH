chr_num = '20';
%read loci file that has genomic locations of TADs
loci_file = sprintf('.././collect_hic_data/chr%s_output_files/loci_tads_level_5kb.txt',chr_num);
loci = load(loci_file);
%make the average FISH distances between TADs

%1- read experimental coordinates file
fname = sprintf('chr%s.xlsx',chr_num);
coor = xlsread(fname);
%2- output file name
out_fname = sprintf('fish_distances_chr%s.csv',chr_num);
n_cells = 111;
n_tads = 30;
calculate_avg_fish_distances(fname,n_tads,n_cells,out_fname);

%3- get the spatial genomic relation
fish_distances = csvread(out_fname);

%relation is : log10(Spatial) = log10(a) + b*log10(Genomic)
%spatial distance in micromiteres
%and genomic distance in basepairs
[a,b] = get_spatial_genomic_relation(fish_distances,loci);

a_new = 10^a;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dir_of_results=sprintf('chr_%s_TAD_level_resolution',chr_num);
lambdaE=12;
lambdaF=-8;
run_gem_general_Rao(dir_of_results,chr_num,a_new,b,lambdaE,lambdaF);





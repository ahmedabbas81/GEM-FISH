function [a,b] = get_spatial_genomic_relation(fish_distances,loci)
S = [];
G = [];
for i = 1 : size(loci,1)
    for j = i+1 : size(loci,1)
        G = [G;log10(loci(j)-loci(i))];
        S = [S;log10(fish_distances(i,j))];
    end
end
p = polyfit(G,S,1);
a = p(2);
b = p(1);

        

function run_gem_general_Rao(dir_of_results,chr_num_string,a_coef,s_g_exp,lambdaE,lambdaF)
mkdir (dir_of_results);
hic_file = sprintf('.././collect_hic_data/chr%s_output_files/hic_tads_level_5kb.txt',chr_num_string);
loci_file = sprintf('.././collect_hic_data/chr%s_output_files/loci_tads_level_5kb.txt',chr_num_string);
l = load(loci_file);
filename=sprintf('fish_distances_chr%s.csv',chr_num_string);
fish_distances = csvread(filename);
fish_distances = fish_distances*1000; %to make in nanometers
l1=5*10^lambdaE;
l2=1*10^lambdaF;
GEM_FISH_TAD_level(hic_file, loci_file, 1E5, l1, 0,l2,fish_distances,a_coef,s_g_exp,dir_of_results);

    



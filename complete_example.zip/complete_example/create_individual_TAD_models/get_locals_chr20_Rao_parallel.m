chr_number = '20';
%volume and size peaks for chr20 (approximate values from Fig S36 in nm^3 and nm, respectively)
vol_chr_orig = 8.0E9;
size_chr_orig = 3050;
g_s_exp = 0.17;
slope = 2.84;
parent_dir = sprintf('chr%s_local_structures_Rao_5kb',chr_number);
g_length_original = 64.4E6; %genomic length of chr20
resolution = 5E3; %resolution 5 Kbp
ntads = 30;
get_local_structures_Rao_parallel(chr_number,ntads,vol_chr_orig,size_chr_orig,g_s_exp,parent_dir,g_length_original,resolution,slope)
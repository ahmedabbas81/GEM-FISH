chr_number = '21';
ntads = 34;
vol_chr_orig = 4.56E9;
size_chr_orig = 2370;
slope = 2.8;
g_s_exp = 0.21;
parent_dir = 'chr21_local_structures_Rao_5kb';
g_length_original = 46E6;
resolution = 5E3;
get_local_structures_Rao_parallel(chr_number,ntads,vol_chr_orig,size_chr_orig,g_s_exp,parent_dir,g_length_original,resolution,slope)
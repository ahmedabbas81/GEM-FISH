
pairs_20 = csvread('Nup153/chr20.csv');
        
pairs_21 = csvread('Nup153/chr21.csv');
pairs_22 = csvread('Nup153/chr22.csv');
[d_E_20,d_SE_20] = validate_Nup_general('20',pairs_20,5000);
[d_E_21,d_SE_21] = validate_Nup_general('21',pairs_21,5000);
[d_E_22,d_SE_22] = validate_Nup_general('22',pairs_22,5000);

d_E = [d_E_20;d_E_21;d_E_22];
d_SE = [d_SE_20;d_SE_21;d_SE_22];
p = ranksum(d_E,d_SE,'tail','left')
if(p<0.05)
    box_plotting(d_E,d_SE,0.05);
else
    box_plotting(d_E,d_SE,nan)
end
% dir_name = 'cmm_nup_se'
% mkdir(dir_name);
% write_cmm_SE('20',dir_name,pairs_20,pairs_20_se);
% write_cmm_SE('21',dir_name,pairs_21,pairs_21_se);
% write_cmm_SE('22',dir_name,pairs_22,pairs_22_se);

% 
% C = [d_E;d_SE];
% group1 = zeros(length(d_E),1);
% group2 = ones(length(d_SE),1);
% groups = [group1;group2];
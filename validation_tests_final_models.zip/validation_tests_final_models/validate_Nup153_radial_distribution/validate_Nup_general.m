function [d_Control_SE,d_SE] = validate_Nup_general(chr_num,pairs_20,resolution)
str_path = sprintf('../final_models_autosomes/chr%s_high_res_str.txt',chr_num);
h_str = load(str_path);
c = calc_centroid(h_str);
R0 = get_max_limit(h_str,c);
tads_file = sprintf('tads_chr%s_hg19.txt',chr_num);
tads = load(tads_file);
ntads = size(tads,1);
k = 1;
for i = 1 : ntads
    loci_file = sprintf('../files_autosomes/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num,i-1);
    loci = load(loci_file);
    blocks(i) = size(loci,1);
    for j = 1 : size(loci,1)
        r_positions(k,1) = loci(j,1);
        r_positions(k,2) = loci(j,1) + resolution-1;
        k = k + 1;
    end
end
    



d_SE = [];
k = 1;
for i = 1 : size(pairs_20,1)
for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=pairs_20(i,1))% && r_positions(j,1)<pairs_20(i,2))
            ind1 = j;
%             if((r_positions(j,1)-pairs_20(i,1))>2500)
%                 ind1 = j-1;
%             else
%                 ind1 = j;
%             end
            break;
        end
    end
    for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=pairs_20(i,2))
            ind2 = j-1;
%             if((r_positions(j,1)-pairs_20(i,2))<2500)
%                 ind2 = j-1;
%             else
%                 ind2 = j-2;
%             end
            break;
        end
    end
%     plot3(h_str(ind1:ind2,1),h_str(ind1:ind2,2),h_str(ind1:ind2,3),'x c','LineWidth',2);
%     hold on
    if(ind2 > ind1)
        flag = 1;
        new_pairs(k,:) = pairs_20(i,:);
        k = k + 1;
        for i1 = ind1 : ind2

            p = h_str(i1,1:3);
            d1 = norm(p-c);
            d_SE = [d_SE;d1/R0];
        end
     end
end

clear pairs_20
pairs_20 = new_pairs;

for i = 1 : size(pairs_20,1)
    size_se = pairs_20(i,2)-pairs_20(i,1);
    t = rand*ntads;
    t_num = round(t)-1;
    if(t_num <= 0)
        t_num = 1;
    end
    tad_start = tads(t_num,1);
    size_tad = tads(t_num,2)-tads(t_num,1);
    start_bp = max(round(rand*size_tad)-2*size_se,1);
    start_ctl_bp = start_bp + tad_start;
    end_ctl_bp = start_ctl_bp + size_se-1;
    control_pairs(i,1) = start_ctl_bp;
    control_pairs(i,2) = end_ctl_bp;
end


d_Control_SE = [];
for i = 1 : size(control_pairs,1)
    for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=control_pairs(i,1))
            ind1 = j;
%             if((r_positions(j,1)-pairs_20(i,1))>2500)
%                 ind1 = j-1;
%             else
%                 ind1 = j;
%             end
            break;
        end
    end
    for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=control_pairs(i,2))
            ind2 = j-1;
%             if((r_positions(j,1)-control_pairs(i,2))<2500)
%                 ind2 = j-1;
%             else
%                 ind2 = j-2;
%             end
            break;
        end
    end
%     plot3(h_str(ind1:ind2,1),h_str(ind1:ind2,2),h_str(ind1:ind2,3),'x c','LineWidth',2);
%     hold on
    for i1 = ind1 : ind2
        
        p = h_str(i1,1:3);
        d1 = norm(p-c);
        d_Control_SE = [d_Control_SE;d1/R0];
    end
end
p = ranksum(d_SE,d_Control_SE);
function write_cmm_SE(chr_num_string,dir_name,pairs,pairs2)
file_path = sprintf('/home/ahmed/gem-master-local-backup_lambdaE_11/feb12_Rao%s/chr_%s_outputs/using_square_difference/structures_and_stats.mat',chr_num_string,chr_num_string);
load(file_path);
G = global_structure;
global_file = sprintf('%s/G_%s.cmm',dir_name,chr_num_string);
fid = fopen(global_file,'w');
fprintf(fid,'<marker_set name="marker set 1">\n');
for i = 1 : size(G,1)
    fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="0" b="1" radius="70"/>\n',i,G(i,1),G(i,2),G(i,3));
    if(i > 1)
        fprintf(fid,'<link id1="%d" id2="%d" r="1" g="0" b="0" radius="20"/>\n',i,i-1);
        
    end
end
fprintf(fid,'</marker_set>');

high_resolution_file = sprintf('%s/H_%s.cmm',dir_name,chr_num_string);
% loci_file_start = sprintf('/home/ahmed/Rao_data/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num_string,starting_tad-1);
% loci = load(loci_file_start);
% for i = 2 : size(loci,1)
%     if(start_bp > loci(i-1,1) && start_bp < loci(i,1))
%         start_point = i;
%         break;
%     end
% end
% SE_start = tad_start_point + start_point;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tad_end_point = 0;
% for i = 1 : ending_tad-1
%     tad_end_point = tad_end_point + blocks(i);
% end
% loci_file_end = sprintf('/home/ahmed/Rao_data/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num_string,ending_tad-1);
% loci = load(loci_file_end);
% for i = 2 : size(loci,1)
%     if(end_bp > loci(i-1,1) && end_bp < loci(i,1))
%         end_point = i;
%         break;
%     end
% end

% SE_end = tad_end_point + end_point;
G = high_resolution_structure;
fid = fopen(high_resolution_file,'w');
fprintf(fid,'<marker_set name="marker set 1">\n');
for i = 1 : size(G,1)
    flag = 0;
    flag1 = 0;
%     if(i >= pairs(1,3) && i<= pairs(1,4))
%         flag1 = 1;
%         fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="0" b="0" radius="55"/>\n',i,G(i,1),G(i,2),G(i,3));
%     end
    for j = 1 : size(pairs2,1)
            if((reduced_positions(i,1)>= pairs2(j,1) && reduced_positions(i,2) <= pairs2(j,2))||(pairs2(j,1)>=reduced_positions(i,1) && pairs2(j,2)<=reduced_positions(i,2)))
                flag1 = 1;
                fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="0" g="1" b="1" radius="70"/>\n',i,G(i,1),G(i,2),G(i,3));
                break;
            end
        end    
    
    %if(flag1 == 0)
       for j = 1 : size(pairs,1)
        if(reduced_positions(i,1)>= pairs(j,1) && reduced_positions(i,2) <= pairs(j,2))
            flag = 1;
            fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="0" b="1" radius="70"/>\n',i,G(i,1),G(i,2),G(i,3));
            break;
        end
    end 
    %end
    if(flag1 == 0 && flag == 0)
        fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="0" g="1" b="0" radius="55"/>\n',i,G(i,1),G(i,2),G(i,3));
    end
%     if(i > 1)
%         fprintf(fid,'<link id1="%d" id2="%d" r="1" g="1" b="0" radius="10"/>\n',i,i-1);
%         
%     end
end
fprintf(fid,'</marker_set>');
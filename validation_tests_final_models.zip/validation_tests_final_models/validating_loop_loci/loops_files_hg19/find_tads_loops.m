function find_tads_loops(chr_num_string)
loops_file = sprintf('loops_chr%s_hg19.csv',chr_num_string);
tads_file = sprintf('tads_chr%s_hg19.txt',chr_num_string);
L = csvread(loops_file);
T = csvread(tads_file);

for i = 1 : size(L,1)
    locus1 = L(i,1);
    t1 = -1;
    locus2 = L(i,3);
    t2 = -1;
    for j = 1 : size(T,1)
        if(locus1 >= T(j,1) && locus1 <= T(j,2))
            t1 = j;
            break;
        end
    end
    
    for j = 1 : size(T,1)
        if(locus2 >= T(j,1) && locus2 <= T(j,2))
            t2 = j;
            break;
        end
    end
    
    if(t1 ~= -1 && t2 ~= -1)
        L(i,5) = t1;
        L(i,6) = t2;
        L(i,7) = abs(t2-t1);
    else
        L(i,5) = -1;
        L(i,6) = -1;
        L(i,7) = -1;
    end
end
savefile = sprintf('loops_tads_hg19_%s.csv',chr_num_string);
csvwrite(savefile,L);
        
    
function validating_loops(chr_num,resolution)%loops,reduced_positions,high_res_distances,tad_positions,resolution)
%read_tads_file
tads_path = sprintf('tads_chr%s_hg19.txt',chr_num);
tad_positions = load(tads_path);
ntads = size(tad_positions,1);
k = 1;
for i = 1 : ntads
    loci_file = sprintf('../files_autosomes/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num,i-1);
    loci = load(loci_file);
    blocks(i) = size(loci,1);
    for j = 1 : size(loci,1)
        reduced_positions(k,1) = loci(j,1);
        reduced_positions(k,2) = loci(j,1) + resolution-1;
        k = k + 1;
    end
end
%read_loops_file
loops_file = sprintf('./loops_files_hg19/loops_chr%s_hg19.csv',chr_num);
loops = load(loops_file);
%read the chr final model
%str_path = sprintf('../final_models_autosomes/chr%s_high_res_str.txt',chr_num);
str_path = sprintf('/home/ahmed/Downloads/GEM-FISH-master/Chr21_modeling_results/final_model_chr21.txt');
structure = load(str_path);
high_res_distances = squareform(pdist(structure));
counters_loops = ones(size(tad_positions,1));
loop_distances = zeros(size(loops,1),2);
counter_loops = 1;
for i = 1 : size(loops,1)
    %get the loop 1st anchor point
    bp1 = loops(i,1);
    bp1_dash = loops(i,2);
    %get the loop 2nd anchor point
    bp2 = loops(i,3);
    bp2_dash = loops(i,4);
    flag_bp1 = 0;
    flag_bp2 = 0;
    ind1 = -1;
    ind2 = -1;
    ind1_tad = -1;
    ind2_tad = -1;
    
    for i1 = 1 : size(reduced_positions,1)
        if((bp1 >= reduced_positions(i1,1) && bp1 < reduced_positions(i1,2)) || (bp1_dash >= reduced_positions(i1,1) && bp1_dash < reduced_positions(i1,2)))
            %if the first anchor point is within the point i1 in the
            %structure
            ind1 = i1;
            %the point of 1st anchor point is i1
            for itad = 1 : size(tad_positions,1)
                if((bp1 >= tad_positions(itad,1) && bp1 < tad_positions(itad,2)) || (bp1_dash >= tad_positions(itad,1) && bp1_dash < tad_positions(itad,2)))
                    ind1_tad = itad;
                    %the tad of first anchor point is itad
                    break;
                end
            end
            break;
        end
    end
    for i1 = 1 : size(reduced_positions,1)
        if((bp2 >= reduced_positions(i1,1) && bp2 < reduced_positions(i1,2)) || (bp2_dash >= reduced_positions(i1,1) && bp2_dash < reduced_positions(i1,2)))
            ind2 = i1;
            %ind2 is the point of the 2nd anchor point
            for itad = 1 : size(tad_positions,1)
                if((bp2 >= tad_positions(itad,1) && bp2 < tad_positions(itad,2)) || (bp2_dash >= tad_positions(itad,1) && bp2_dash < tad_positions(itad,2)))
                    ind2_tad = itad;
                    %ind2_tad is the tad # of the 2nd anchor point
                    break;
                end
            end
            break;
        end
    end
    
    if(ind1 == -1 || ind2 == -1)
        continue;
    else
        
        g_dist = abs(reduced_positions(ind2,1) - reduced_positions(ind1,1)); %the genomic distance between the two anchors of the loop
        ind3 = -1;
        for k1 = 1 : size(reduced_positions,1)
            for itad = 1 : size(tad_positions,1)
                if((reduced_positions(k1,1) >= tad_positions(itad,1) && reduced_positions(k1,2) < tad_positions(itad,2)))
                    indk_tad = itad;
                    break;
                end
            end
            g_dist1 = abs(reduced_positions(k1,1) - reduced_positions(ind1,1));
            g_dist2 = abs(reduced_positions(k1,1) - reduced_positions(ind2,1));
                flag_1 = 0;

                if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist2)<resolution)  %%control point is on the right side of loop anchor 2
                    if(ind1_tad ~= ind2_tad && ind2_tad ~= indk_tad && abs(ind1_tad-ind2_tad) == abs(indk_tad-ind2_tad))
                        ind3 = k1;
                        ind4 = ind2;
                        flag_1 = 1;
                    elseif(ind1_tad == ind2_tad && ind2_tad == indk_tad)
                        ind3 = k1;
                        ind4 = ind2;
                        flag_1 = 1;
                    end
                    if(flag_1 == 1)
                        break;
                    end
                end
                if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist1)<resolution)  %%control point on the left side of loop anchor 1
                    if(ind1_tad ~= ind2_tad && ind1_tad ~= indk_tad && abs(ind1_tad-ind2_tad) == abs(indk_tad-ind1_tad))
                        ind3 = k1;
                        ind4 = ind1;
                        flag_1 = 1;
                    elseif(ind1_tad == ind2_tad && ind1_tad == indk_tad)
                        ind3 = k1;
                        ind4 = ind1;
                        flag_1 = 1;
                    end
                    if(flag_1 == 1)
                        break;
                    end
                end
%                 if((k1 ~= ind1 && k1 ~= ind2) && abs(g_dist-g_dist2)<=5000)
%                     ind3 = k1;
%                     ind4 = ind2;
%                     break;
%                 end
            end
            %continue;
        end
        if(ind3 == -1) %means we didnt find a fair control point
            continue;
        else
            for itad = 1 : size(tad_positions,1)
                    if((reduced_positions(ind3,1) >= tad_positions(itad,1) && reduced_positions(ind3,2) < tad_positions(itad,2)))
                        ind3_tad = itad;
                        break;
                    end
            end
                for itad = 1 : size(tad_positions,1)
                    if((reduced_positions(ind4,1) >= tad_positions(itad,1) && reduced_positions(ind4,2) < tad_positions(itad,2)))
                        ind4_tad = itad;
                        break;
                    end
                end
        end
        loop_distances(i,1) = high_res_distances(ind1,ind2);%spatial distance between loop loci of loop i
        loop_distances2(i,1) = abs(reduced_positions(ind2,1) - reduced_positions(ind1,1));%genomic distance
        loop_distances(i,2) = high_res_distances(ind3,ind4); %spatial distance between control anchor points
        loop_distances2(i,2) = abs(reduced_positions(ind3,1) - reduced_positions(ind4,1));
        index = abs(ind2_tad - ind1_tad) + 1;
        inner_loop_index = counters_loops(index);
%       loop_distances_output(index,inner_loop_index) = (1.0*loop_distances(i,3))/loop_distances(i,1);
        loop_distances3(counter_loops) = loop_distances2(i,1)*1.0/loop_distances(i,1);
%         loop_distances4(counter_loops,1) = ind1;
%         loop_distances4(counter_loops,2) = ind2;
%         loop_distances4(counter_loops,3) = bp1;
%         loop_distances4(counter_loops,4) = bp2;
%         loop_distances4(counter_loops,5) = abs(reduced_positions(ind1,1)-reduced_positions(ind2,1));
%         loop_distances4(counter_loops,6) = loop_distances(i,1);
%         loop_distances4(counter_loops,7) = ind3;
%         loop_distances4(counter_loops,8) = ind4;
%         loop_distances4(counter_loops,9) = abs(reduced_positions(ind3,1)-reduced_positions(ind4,1));
%         loop_distances4(counter_loops,10) = loop_distances(i,2);
%         loop_distances4(counter_loops,11) = ind1_tad;
%         loop_distances4(counter_loops,12) = ind2_tad;
%         loop_distances4(counter_loops,13) = ind3_tad;
%         loop_distances4(counter_loops,14) = ind4_tad;
        control_distances3(counter_loops) = loop_distances2(i,2)*1.0/loop_distances(i,2);
        counter_loops = counter_loops+1;                
    end

pvalue = ranksum(control_distances3,loop_distances3,'tail','left')
C = control_distances3'/1000;
L = loop_distances3'/1000;
if(pvalue<0.05)
    box_plotting(C,L,0.05);
else
    box_plotting(C,L,nan);
end
% C = [control_distances3/1000,loop_distances3/1000];
% G = [zeros(1,length(control_distances3)),ones(1,length(loop_distances3))];
% figure,
% box_plot(C,G);
% ylabel('Packing density (Kbp/nm)')
% set(gca,'xticklabel',{'Control loci','loop loci'},'FontSize',14)

        
    
            
function centroid = calc_centroid(structure)
x_bar = mean(structure(:,1));
y_bar = mean(structure(:,2));
z_bar = mean(structure(:,3));
centroid = [x_bar,y_bar,z_bar];
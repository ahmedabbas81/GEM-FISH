clear all

%super-enhancer locations in the 3 autosomes as obtained from 
%dbSUPER: a database of super-enhancers in mouse and human genome, published in 2016 NAR Database Issue.
pairs_20 = [54983631,55020034;
            48899266,48939231;
            45963566,45990595;
            43964972, 43988027;
            30286359 ,30311380;
            52195994 ,52241045;
            33890505 ,33909136;
            45943253 ,45949679;
            3777069 ,3793364;
            49261463 ,49273374;
            4917074 ,4932654];
        
pairs_21 = [47468608,47520268;
            46712039,46751100;
            36253336,36264176;
            43458580,43478619;
            46459591,46472484
            ];
pairs_22 = [36717194,36767560;
            30589152,30609846;
            30630526,30651581;
            33016902,33026128;
            45924431,45950508;
            28247557,28283972];
[d_E_20,d_SE_20] = validate_SE_general('20',pairs_20,5000);
[d_E_21,d_SE_21] = validate_SE_general('21',pairs_21,5000);
[d_E_22,d_SE_22] = validate_SE_general('22',pairs_22,5000);

d_E = [d_E_20;d_E_21;d_E_22];
d_SE = [d_SE_20;d_SE_21;d_SE_22];
p = ranksum(d_E,d_SE,'tail','left')
if(p < 0.05)
    box_plotting(d_E,d_SE,0.05);
else
    box_plotting(d_E,d_SE,nan);
end


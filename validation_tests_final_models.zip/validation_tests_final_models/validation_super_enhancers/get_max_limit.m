function r = get_max_limit(structure,c)
r = 0;
for i = 1 : size(structure,1)
    p = structure(i,:);
    d = norm(p-c);
    if(d > r)
        r = d;
    end
end
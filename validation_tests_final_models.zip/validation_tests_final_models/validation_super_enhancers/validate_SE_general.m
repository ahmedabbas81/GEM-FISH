function [d_E,d_SE] = validate_SE_general(chr_num,pairs_20,resolution)
str_path = sprintf('../final_models_autosomes/chr%s_high_res_str.txt',chr_num);
h_str = load(str_path);
c = calc_centroid(h_str);
R0 = get_max_limit(h_str,c);
tads_file = sprintf('tads_chr%s_hg19.txt',chr_num);
tads = load(tads_file);
ntads = size(tads,1);
k = 1;
for i = 1 : ntads
    loci_file = sprintf('../files_autosomes/Rao_files_%s_5kb/loci_tad_%d_Rao_5kb.txt',chr_num,i-1);
    loci = load(loci_file);
    blocks(i) = size(loci,1);
    for j = 1 : size(loci,1)
        r_positions(k,1) = loci(j,1);
        r_positions(k,2) = loci(j,1) + resolution-1;
        k = k + 1;
    end
end
%read regular enhancers file
enhancers_file = sprintf('chr_%s_enhancers.txt',chr_num);
E = load(enhancers_file);
d_E = [];

for i = 1 : size(h_str,1)
    h_str(i,4) = 0;
end
for i = 1 : size(E,1)
    for j = 1 : size(r_positions,1)
        if(E(i,1)>=r_positions(j,1) && E(i,1)<r_positions(j,2))
%             plot3(h_str(j,1),h_str(j,2),h_str(j,3),'x c','LineWidth',2);
%             hold on
            if(h_str(j,4) == 1)
                continue;
            end
            p = h_str(j,1:3);
            h_str(j,4) = 1;
            d1 = norm(p-c);
            d_E = [d_E;d1/R0];
            break;
        end
    end
end
% figure,
% hist(d_E);
% figure,
% plot3(h_str(:,1),h_str(:,2),h_str(:,3),'x m','LineWidth',2);
% hold on
d_SE = [];
for i = 1 : size(pairs_20,1)
    ind1 = -1;
    ind2 = -1;
    for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=pairs_20(i,1))
            ind1 = j;
%             if((r_positions(j,1)-pairs_20(i,1))>2500)
%                 ind1 = j-1;
%             else
%                 ind1 = j;
%             end
            break;
        end
    end
    for j = 1 : size(r_positions,1)
        if(r_positions(j,1)>=pairs_20(i,2))
            ind2 = j-1;
%             if((r_positions(j,1)-pairs_20(i,2))<2500)
%                 ind2 = j-1;
%             else
%                 ind2 = j-2;
%             end
            break;
        end
    end
%     plot3(h_str(ind1:ind2,1),h_str(ind1:ind2,2),h_str(ind1:ind2,3),'x c','LineWidth',2);
%     hold on
    if(ind2 > ind1)
        for i1 = ind1 : ind2

            p = h_str(i1,1:3);
            d1 = norm(p-c);
            d_SE = [d_SE;d1/R0];
        end
    end
end

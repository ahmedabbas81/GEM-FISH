function validate_radial_distance(chr_num,n_iter)
for cell = 1 : 8
    bins = 5;
    for iter = 0 : n_iter
        if(iter == 0)
            filename = sprintf('/home/Ahmed/chromosomes_individual_data/chr%s/result_cell%d_iter%d.txt/conformation1.txt',chr_num,cell,iter);
        else
            filename = sprintf('/home/Ahmed/chromosomes_individual_data/chr%s/result_cell%d_iter%d_feedback/conformation1.txt',chr_num,cell,iter);
        end
        if(exist(filename,'file')~=2)
            continue;
        end
        if(iter>0)
            clear H
        end
        H = load(filename);
%        [ rmse,H ] = SVD3D( H,B);
        c = calc_centroid(H);
        R0 = get_max_limit(H,c);
        delta_r = R0/bins;
        annotations_path = sprintf('/home/Ahmed/chromosomes_individual_data/chr%s/annotations1.txt',chr_num);
        if(exist(annotations_path,'file') == 2)
            Classes = load(annotations_path);
        else
            return;
        end
        
       for i = 1 : size(H,1)
            p = H(i,1:3);
            d = norm(p-c);
            H(i,5) = d;
            H(i,4) = Classes(i);
       end
       k = 1;
        for r0 = 0 : delta_r : R0-delta_r
            rho_active(iter+1,k) = 0;
            rho_inactive(iter+1,k) = 0;
            for l = 1 : size(H,1)
                if(H(l,5)>=r0 && H(l,5)<r0+delta_r && H(l,4) == 1)
                    rho_active(iter+1,k) = rho_active(iter+1,k) + 1;
                end
                if(H(l,5)>=r0 && H(l,5)<r0+delta_r && H(l,4) == -1)
                    rho_inactive(iter+1,k) = rho_inactive(iter+1,k) + 1;
                end
            end
            k = k + 1;
        end
        fname = sprintf('./using_annotations/cell%d/using_annotations_iter%d_chr19.cmm',cell,iter);
        fid = fopen(fname,'w');
        fprintf(fid,'<marker_set name="marker set 1">\n');
        for i = 1 : size(H,1)  
            if(H(i,4) == -2)
                continue;
            end

                if(H(i,4) == 1)
                    fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="0" b="1" radius="70"/>\n',i,H(i,1),H(i,2),H(i,3));
                elseif(H(i,4) == 2)
                    fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="0" g="1" b="1" radius="70"/>\n',i,H(i,1),H(i,2),H(i,3));
                else
                    fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="1" b="1" radius="50"/>\n',i,H(i,1),H(i,2),H(i,3));
                end
        %     if(i > 1)
        %         fprintf(fid,'<link id1="%d" id2="%d" r="1" g="1" b="0" radius="20"/>\n',i,i-1);
        %     end
        end
        fprintf(fid,'</marker_set>');
        clear structure PC
    end
    sum_active = sum(rho_active(1,:));
    sum_inactive = sum(rho_inactive(1,:));
    rho_active = rho_active/sum_active;
    rho_inactive = rho_inactive/sum_inactive;
    fname = sprintf('cell%d_2.mat',cell);
    save(fname,'rho_active','rho_inactive')
    
end
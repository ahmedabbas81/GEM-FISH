for chr = 20 : 22
    chr_num = num2str(chr);
    str_path = sprintf('../final_models_autosomes/chr%s_high_res_str.txt',chr_num);
    str = load(str_path);
    op_file = sprintf('chr%s_final_model.cmm',chr_num);
    write_cmm_file(op_file,str);
end
    
function write_cmm_file(fname,str)
fid = fopen(fname,'w');
fprintf(fid,'<marker_set name="marker set 1">\n');
for i = 1 : size(str,1)
    fprintf(fid,'<marker id="%d" x="%.3f" y="%.3f" z="%.3f" r="1" g="0" b="1" radius="70"/>\n',i,str(i,1),str(i,2),str(i,3));
%     if(i > 1)
%         fprintf(fid,'<link id1="%d" id2="%d" r="1" g="0" b="0" radius="20"/>\n',i,i-1);
%         
%     end
end
fprintf(fid,'</marker_set>');
